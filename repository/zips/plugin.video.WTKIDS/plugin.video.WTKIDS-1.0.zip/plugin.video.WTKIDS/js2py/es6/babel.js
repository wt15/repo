// run buildBabel in this folder to convert this code to python!
var babel = require("babel-core");
var babelPresetEs2015 = require("babel-preset-es2015");

Object.babelPresetEs2015 = babelPresetEs2015;
Object.babel = babel;
