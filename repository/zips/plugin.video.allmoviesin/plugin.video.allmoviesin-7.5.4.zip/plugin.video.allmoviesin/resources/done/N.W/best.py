import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['tv']


def decode(r,nm):
  
    a2=r.split('-')
    a0 = nm
    a1=''
    for i in range (0, len( a2)) :
        xh=int('0x'+a2[i], 0)-a0
        
        #xh = S['\x45\x44\x6f\x64\x43'](S[Usrb('0x39', '\x50\x5e\x6a\x6a')](parseInt, a2[i], 0x10), a0);
        #var a3 = String[Usrb('0x3a', '\x6e\x58\x5d\x49')](xh);
       
        a3=chr(xh)
        a1=a1+a3
        #var a1 = S[Usrb('0x3b', '\x6b\x61\x23\x63')](a1, a3);
    return a1
def get_code(html):
    regex='\(parseInt,.+?,0x10\),(.+?)\)'
    cc=re.compile(regex).findall(html)
    regex='var %s\=(.+?)\;'%cc[0]
    rr=re.compile(regex).findall(html)
   
    return int(rr[0].split('0x')[1], 16)
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        start_time=time.time()

        
        
        progress=' Start '
        all_links=[]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = {
          'q': clean_name(original_title,1).lower(),
          'limit': '8',
          'timestamp': str(time.time()*100),
          'verifiedCheck': ''
        }

        response = requests.post('https://best-series.me/ajax/search.php', headers=headers, data=data).json()
        once=0
        
        for item in response:
            if stop_all==1:
                break
            if clean_name(original_title,1).lower() in item['title'].lower() and show_original_year == str(item['year']):
                x=requests.get(item['permalink'], headers=headers).content
                regex='<a title=".+?" href="(.+?)" class="episode">Season %s Ep. %s<'%(season,episode)
                m=re.compile(regex).findall(x)
                print x
                if len(m)>0:
                    
                    y=requests.get(m[0], headers=headers).content
                    regex="onclick=\"window.open\(dbneg\('(.+?)'"
                    m2=re.compile(regex).findall(y)
                    if once==0:
                        once=1
                        nm=get_code(y)
                       
                    for items in m2:
                        if stop_all==1:
                            break
                        link=decode(items,nm)
                       
                        name1,match_s,res,check=server_data(link,original_title)
                        
                      
                        if check:
                              all_links.append((name1.replace("%20"," "),link,match_s,res))
                        
                              global_var=all_links
        
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links