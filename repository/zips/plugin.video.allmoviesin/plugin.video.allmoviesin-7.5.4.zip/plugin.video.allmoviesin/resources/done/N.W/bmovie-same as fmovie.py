# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[9]



def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    global global_var
    all_links=[]
    if tv_movie=='tv':
      url=domain_s+'bmovie.cc/?s=%s'%(clean_name(original_title,1)+'+season+'+season).replace('%20','+').replace(' ','+')
    else:
      url=domain_s+'bmovie.cc/?s=%s'%(clean_name(original_title,1)+'+'+show_original_year).replace('%20','+').replace(' ','+')
 
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        #'Host': 'bmovies.film',
        'Pragma': 'no-cache',
        #'Referer': 'https://bmovies.film/search-query/the+matrix/',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    
    

    response = requests.get(url, headers=headers).content
    regex='<a class="titlecover" style="" href="(.+?)">(.+?)<'
    match=re.compile(regex).findall(response)

  
  
    for link,name in match:
       
        if stop_all==1:
            break
        if clean_name(original_title,1).lower() in name.lower().replace('&#039;',"'"):
            x = requests.get(link, headers=headers).content
            if tv_movie=='tv':
                regex='id="active-.+?-%sx%s".+?loadDoc\(\'(.+?)\''%(season,episode)
                
            else:
               regex="loadDoc\('(.+?)'"
            match2=re.compile(regex).findall(x)
            
            for links_in in match2:
                
                headers = {
                    'pragma': 'no-cache',
                    
                    'accept-encoding': 'utf-8',
                    'accept-language': 'en-US,en;q=0.9',
                    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
                    'accept': '*/*',
                    'cache-control': 'no-cache',
                    'authority': 'bmovie.cc',
                    'referer': link,
                }
                y=requests.get(links_in, headers=headers).content
                
                regex='src="(.+?)"'
                mm=re.compile(regex).findall(y)
                headers = {
                    'authority': 'bmovie.cc',
                    'pragma': 'no-cache',
                    'cache-control': 'no-cache',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                    'referer': link,
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    #'cookie': '__cfduid=d69279d97b03c1d34ae7d100f7723d55d1543402391; _ga=GA1.2.231080714.1543402402; _gid=GA1.2.1828638748.1543402402; starstruck_1d2f5112c3c0833eba0a41a48fefb792=b28c97a96d0f5279ca55096780700343',
                }

                params = (
                    ('hash', 'NTNSa2dkS2tGeUhkR2ZYSFFKZ0RScEZtNnlTU2V2cDBhQjIraC9jTkg4RmpTK3o2RTFTNUZSa1QyVWY4KzFaYm92ckpWbFR0NG5zQStTNEcyUVY2b0E9PQ=='),
                )

                response = requests.get(mm[0], headers=headers).url
                if '?' in response:
                    response=response.split('?')[0]
                
                name1,match_s,res,check=server_data(response,original_title)

                
                if check:
                    if res==" ":
                      res='720'
                    all_links.append((name1,response,match_s,res))
                    global_var=all_links
    return global_var
    