import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['movie','tv']
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        all_links=[]
        start_time=time.time()
        headers = {
            'Pragma': 'no-cache',
            'Origin': 'https://yabancidizi.vip',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Cache-Control': 'no-cache',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Referer': 'https://yabancidizi.vip/',
            'Content-Length': '0',
        }

       

        

        params = (
            ('qr', clean_name(original_title,1).lower()),
        )

        response = requests.post('https://yabancidizi.vip/search', headers=headers, params=params).json()
        
       
        
        for items in response['data']['result']:
            print items['s_name']
            print items['s_year']
            if items['s_name'].lower()==clean_name(original_title,1).lower() and items['s_year']==show_original_year:
                print 'in'
                if tv_movie=='tv':
                    added='/sezon-%s/bolum-%s'%(season,episode)
                    
                else:
                    added=''
                
                if tv_movie=='tv':
                    subf='dizi/'
                else:
                    subf='film/'
                print 'getin'
                y=requests.get( 'https://yabancidizi.vip/'+subf+items['s_link']+added,headers=base_header).content
                print 'got'
                regex='data-hash="(.+?)" data-link="(.+?)"'
                print 'regex'
                m=re.compile(regex).findall(y)
                print 'regex d'
                for hash,lk in m:
                    
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
                        'Accept': 'application/json, text/javascript, */*; q=0.01',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'X-Requested-With': 'XMLHttpRequest',
                        'Connection': 'keep-alive',
                        'Referer': 'https://yabancidizi.vip/'+subf+items['s_link']+added,
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }

                    data = {
                      'link': lk,
                      'hash': hash,
                      'querytype': 'alternate',
                      'type': 'videoGet'
                    }
                    print 'hasg d'
                    r = requests.post('https://yabancidizi.vip/ajax/service', headers=headers, data=data).json()
                    print 'hash d d'
                    headers = {
                        'authority': 'yabancidizi.vip',
                        'pragma': 'no-cache',
                        'cache-control': 'no-cache',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                        'sec-fetch-site': 'same-origin',
                        'sec-fetch-mode': 'nested-navigate',
                        'referer': 'https://yabancidizi.vip/'+subf+items['s_link']+added,
                        'accept-encoding': 'utf-8',
                        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                        
                    }
                    print 'hash d d1'
                    print r['api_iframe']
                    
                    x=requests.get(r['api_iframe'],headers=headers).content
                    print 'hash d d2'
                    regex='iframe.+?src="(.+?)"'
                    print 'hash d d3'
                    mm=re.compile(regex).findall(x)
                    print 'hash d d4'
                    if len(mm)>0:
                        name1,match_s,res,check=server_data(mm[0],original_title)
                       
                        if check:
                              all_links.append((name1.replace("%20"," "),mm[0],match_s,res))
                        
                              global_var=all_links
                    

        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links