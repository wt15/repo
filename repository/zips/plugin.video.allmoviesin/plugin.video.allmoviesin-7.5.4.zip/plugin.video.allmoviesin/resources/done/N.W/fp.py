# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,res_q
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[108]
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    import os
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    dir_path =os.path.dirname(os.path.realpath(__file__))
    mypath=os.path.join(dir_path,'cache_f')
    servers_db=(os.path.join(mypath,'servers.db'))
    progress='Start'
    start_time=time.time()
    all_links=[]
    headers={'Content-Type': 'application/x-www-form-urlencoded',
             'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; Le X526 Build/IIXOSOP5801910121S)',
             'Connection': 'Keep-Alive',
             'Accept-Encoding': 'gzip',
             #"Content-Length": "63", 
             }
    dbconserver = database.connect(servers_db)
    dbcurserver = dbconserver.cursor()
    
    if tv_movie=='movie':
        quary=clean_name(original_title,1)+' '+show_original_year
    else:
        quary=clean_name(original_title,1)+' S'+season_n+'E'+episode_n
    for page in range(0,5):
        
        body="searchQuery=%s&startrow=%s&type=video&filetype=&sort=dateasc"%(quary,str(page*20))
       


        progress='Requets'
        html=requests.post('https://filepursuit.com/jsn/v1/search.php?q=%s&type=video&sort=dateasc&start_page=%s'%(quary,str(page*20)),headers=headers,data=body).content
        if 'no rows' in html:
            break
        all_l=[]
        count=0
        for items in json.loads(html):
            progress='Links-'+str(count)
            count+=1
            link=items['link']
            if link not in all_l:
                all_l.append(link)
                regex='//(.+?)/'
                match_s=re.compile(regex).findall(link)[0]
                dbcurserver.execute("SELECT speed FROM servers WHERE name = '%s'"%(match_s))

                match = dbcurserver.fetchone()
                ok=0
                
                if match!=None:
           
                  if match[0]!='TIMEOUT' and float(match[0])<0.6:
                    ok=1
                else:
                  ok=1
                if Addon.getSetting("filter_fp")=='false':
                  ok=1
                if ok==1:
                    name1=items['filename']
                    if 'trailer' in name1.lower():
                        continue
                    size=items['filesize']
                    regex='^(.+?) (.+?)$'
                    m=re.compile(regex).findall(size)
                    if len(m)>0:
                        val_s=m[0][0].replace(',','')
                        val_c=m[0][1].replace(',','')
                        if val_c=='MB':
                            size=str(round(float(val_s)/1024, 2))+' GB'
                        else:
                            size=val_s+' GB'
                    res=res_q(name1)
                    if res==' ':
                        res=res_q(link)
                    all_links.append((name1,link,'Direct - '+size,res))
                    
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    




