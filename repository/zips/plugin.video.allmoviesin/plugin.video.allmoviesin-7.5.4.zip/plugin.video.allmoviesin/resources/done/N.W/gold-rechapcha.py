# -*- coding: utf-8 -*-
import logging

import requests,PTN
import unjuice,time,cache
from urlparse import urljoin
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,res_q
type=['movie','tv']

import urllib2,urllib,base64,json

color=all_colors[68]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
 
    all_links=[]
    if tv_movie=='tv':
        search_url='http://goldmovies.xyz/?s='+clean_name(original_title,1).replace(' ','+')+'+season+%s+episode+%s'%(season,episode)
    else:
        search_url='http://goldmovies.xyz/?s='+clean_name(original_title,1).replace(' ','+')
    progress='requests'
    x=requests.get(search_url,headers=base_header).content
    progress='Regex'
    regex='data-movie-id=(.+?)/p>'
    m_pre=re.compile(regex,re.DOTALL).findall(x)
    count=0
    for items in m_pre:
        
        progress='Links-'+str(count)
        count+=1
        if tv_movie=='tv':
            regex='href="(.+?)".+?class="qtip-title">(.+?)<.+?<p>(.+?)<'
        else:
            regex='href="(.+?)".+?class="qtip-title">(.+?)<.+?rel="tag">(.+?)<'
        match=re.compile(regex,re.DOTALL).findall(items)
        
        for link,name,year in match:
            
            progress='Links2-'+str(count)
            if stop_all==1:
                        break
            check=False
            if tv_movie=='tv':
                
                if 'season %s episode %sqq'%(season,episode) in name.lower()+'qq':
                    check=True
            else:
                if year==show_original_year:
                    check=True
           
      
            if clean_name(original_title,1).lower() in name.lower() and check:
                progress='requests2-'+str(count)
                print link
                y=requests.get(link,headers=base_header).content
               
                regex='\[bzplayer(.+?)\]'
                match2=re.compile(regex,re.DOTALL).findall(y)[0]
                
                regex='mk.+?="(.+?)" mk.+?_label="(.+?)"'
                match3=re.compile(regex).findall(match2)
               
                for items,res in match3:
                   
                    names=items.split('/')
                    name1=names[len(names)-1]
                    name2,match_s,res2,check=server_data(items,original_title)
                        
      
                    if check :
                        size=''
                        if '-' in match_s:
                            size=' - '+match_s.split('-')[1]
                        all_links.append((name1.replace("%20"," "),items,'Direct '+size,res))                
                    
                    global_var=all_links
    
 

    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
                
