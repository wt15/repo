import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie']

rating=['SSS','7M/s']

import urllib2,urllib,logging,base64,json
color=all_colors[80]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all


    import cfscrape,json,urllib
    all_links=[]
    headers={
    'User-Agent':"Dalvik/2.1.0 (Linux; U; Android 7.0; S16 Build/NRD90M)"
    }
    url='http://jajar.xyz/mov/api.php?search='+clean_name(original_title,1)
    
    html=requests.get(url,headers=headers).content
    print items
    for items in html['LIVETV']:
        if stop_all==1:
                    break
        if clean_name(original_title,1).lower() in items['channel_title'].lower() and show_original_year in items['channel_title']:
            url2='http://jajar.xyz/mov/api.php?channel_id='+items['id']
            x=requests.get(url2,headers=headers).json()
            for in_items in x['LIVETV']:
                if stop_all==1:
                    break
                if 'view' not in in_items['channel_url']:
                    regex='https://www.googleapis.com/drive/v3/files/(.+?)\?'
                    match=re.compile(regex).findall(in_items['channel_url'])
                    f_link='https://drive.google.com/file/d/'+match[0]+'/view'
                    res=in_items['quality']
                    if res=='HD':
                      res='720'
                    all_links.append((clean_name(original_title,1),f_link,'Google',res))
               
                    global_var=all_links
                else:
                    res=in_items['quality']
                    if res=='HD':
                      res='720'
                    all_links.append((clean_name(original_title,1),in_items['channel_url'],'Google',res))
               
                    global_var=all_links
                        

    return all_links
            