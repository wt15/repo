# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie','subs']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[37]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id,dub='no'):
     global global_var,stop_all

     name=name.replace("%3a","")
     
     url=domain_s+'thelinkia.blogspot.co.il/'
     all_links=[]
     headers = {
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Language': 'en-US,en;q=0.5',
     'Cache-Control': 'no-cache',
     'Connection': 'keep-alive',
     #'Host': 'thelinkia.blogspot.co.il',
     'Pragma': 'no-cache',
     'Upgrade-Insecure-Requests': '1',
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
     }
     
     html=requests.get(url,headers=headers).content
     regex="'post-count-link' href='(.+?)'"
     match=re.compile(regex).findall(html)
     found=0
     
     
     f_link=''
     if tv_movie=='tv':
       url=domain_s+'thelinkia.blogspot.co.il/search/label/'+name+'%20%D7%A2%D7%95%D7%A0%D7%94%20'+(season)
     else:
       url=domain_s+'thelinkia.blogspot.co.il/search/label/'+name.replace('+',"%20")
     yy=requests.get(url,headers=headers).content

     regex="h3 class='post-title entry-title'.+?a href='(.+?)'>(.+?)</a>"
     match=re.compile(regex,re.DOTALL).findall(yy)
     for link,name_in in match:
         
         if tv_movie=='movie':
           if dub=='yes':
             second_con='מדובב'
           else:
             second_con=name_in
           string_for_check=show_original_year
         else:
           string_for_check='עונה %s, פרק %s'%(season,episode)+"$$$$$"
           second_con=name_in
         if urllib.unquote_plus(name) in name_in and string_for_check in name_in+"$$$$$" and second_con in name_in:
           f_link=link
           f_name=name_in
      
           break
     if f_link!='':
         zz=requests.get(f_link,headers=headers).content
         regex='<b><a href="(.+?)" target="_blank">'
         match=re.compile(regex).findall(zz)
         for links_f in match:
              name1,match_s,res,check=server_data(links_f,f_name)
              if check :
                all_links.append((f_name,links_f,match_s,res))
                global_var=all_links
     return global_var
     