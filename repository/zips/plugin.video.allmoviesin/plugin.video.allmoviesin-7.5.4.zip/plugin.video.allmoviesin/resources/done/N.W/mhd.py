# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,client,all_colors
type=['tv','movie']
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl

import urllib2,urllib,logging,base64,json
color=all_colors[40]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
           
            'Pragma': 'no-cache',
            
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
        if tv_movie=='movie':
          url='http://megashare.gg/search-query/'+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
        else:
          url='http://megashare.gg/search-query/'+clean_name(original_title,1).replace(' ','+')+'+season+'+season
        x=requests.get(url,headers=headers,verify=False).content
        all_links=[]
        regex_pre='<div class="ml-item">(.+?)</div>'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        from jsunpack import unpack
        for items in match_pre:
            if stop_all==1:
                    break
            regex='<a href="(.+?)".+?<h2>(.+?)</h2>'
            match=re.compile(regex,re.DOTALL).findall(items)
            for link,name_in in match:
              if 'dubb' in name_in.lower():
                continue
              if stop_all==1:
                    break
              if clean_name(original_title,1).lower() not in name_in.lower():
                continue
              y=requests.get(link+'watching/',headers=headers,verify=False).content
     
              if tv_movie=='tv':
                regex='<li id="episode(.+?)</li>'
                match2=re.compile(regex,re.DOTALL).findall(y)
               
                for items_in in match2:
                  if stop_all==1:
                    break
                  if 'Episode %s:'%episode_n in items_in:
                    regex_in='data-drive="(.+?)"'
                    match_link=re.compile(regex_in).findall(items_in)
                    name_in=original_title
              else:
                  regex_p1='id="servers-list">(.+?)</ul>'
                  match_pre=re.compile(regex_p1,re.DOTALL).findall(y)[0]
                  regex='data-.+?"(.+?)"'
                  match_link=re.compile(regex).findall(match_pre)
              for links in match_link:
              
                if stop_all==1:
                    break
                if '1megavideo.live' in links or 'movierulz' in links:
           
                    z=requests.get(links,headers=headers,verify=False).content
                    regex="<script type='text/javascript'>(.+?)</script>"
                    match_in=re.compile(regex,re.DOTALL).findall(z)[0]
                    holder = unpack(match_in)
                    regex='sources:\[(.+?)\]'
                    
                    match_in_p=re.compile(regex,re.DOTALL).findall(holder)[0]
                    if 'file' in match_in_p:
                        regex='file:"(.+?)"'
                        match_in=re.compile(regex).findall(match_in_p)
                        regex='label:"(.+?)"'
                        match_q=re.compile(regex).findall(match_in_p)[0]
                    else:
                        match_in=[match_in_p]
                        match_q=' '
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': links,
                        'Origin': 'https://1megavideo.live',
                        'Connection': 'keep-alive',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }
                    for links_in in match_in:
                       if stop_all==1:
                          break
                       head=urllib.urlencode(headers)
                    
                       links_in=links_in
                       all_links.append((name_in.replace("%20"," "),links_in,'Direct',match_q))
                       global_var=all_links
                
                else:
                    if resolveurl.HostedMediaFile(links).valid_url():
                 
                           name1,match_s,res,check=server_data(links,name_in)
                           if check:
                              all_links.append((name1.replace("%20"," "),links,match_s,res))
                              global_var=all_links
        return global_var