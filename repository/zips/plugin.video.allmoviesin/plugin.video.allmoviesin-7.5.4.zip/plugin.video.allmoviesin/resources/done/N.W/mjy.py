# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
   
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    
    search_string=clean_name(original_title,1)
    
    url='https://www.moviesjoy.net/search/'+search_string.replace(' ','+')
    progress='requests'
    p = requests.get(url,headers=headers).content
    regex='<div class="flw-item">.+?<a href="(.+?)".+?title="">(.+?)<.+?<div class="film-infor"><span>(.+?)<'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(p)
    count=0
    
    for link,title,year in match:
        progress='Links-'+str(count)
        count+=1
        check=False
        
        if tv_movie=='tv':
            if 'Season '+season in title:
                check=True
        else:
            if show_original_year==year:
                check=True
        if search_string.lower() in title.lower() and check:
            progress='requests-'+str(count)
            x = requests.get(link,headers=headers).content
            regex='div class="dp-w-cover".+?<a href="(.+?)"'
            progress='Regex-'+str(count)
            match2=re.compile(regex,re.DOTALL).findall(x)[0]
            progress='requests2-'+str(count)
            y= requests.get(match2,headers=headers).content
            
            regex='id: "(.+?)".+?movie_id: "(.+?)"'
            progress='Regex2-'+str(count)
            match3=re.compile(regex,re.DOTALL).findall(y)[0]
            id=match3[0]
            mid=match3[1]
            headers = {
                'pragma': 'no-cache',
                'cookie': '__cfduid=d92be25b15d3c178ee994ae7264fa5aee1547710421; _ga=GA1.2.1684250511.1547710419; _gid=GA1.2.2101589750.1547710419; __dtsu=2DE7B66BEA2F405C2159DF6C02639E31; __zlcmid=qPhwq7cJ4wKCfE; view-26467=true; __atuvc=6%7C3; __atuvs=5c4045458625a21c003',
                'accept-encoding': 'utf-8',
                'accept-language': 'en-US,en;q=0.9',
                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
                'accept': 'application/json, text/javascript, */*; q=0.01',
                'cache-control': 'no-cache',
                'authority': 'www.moviesjoy.net',
                'x-requested-with': 'XMLHttpRequest',
                'referer': match2,
            }
            progress='requests3-'+str(count)
            response = requests.get('https://www.moviesjoy.net/ajax/v4_movie_episodes/%s/%s'%(id,mid), headers=headers).json()
            regex='<li(.+?)</li>'
            m3=[]
            progress='Regex3-'+str(count)
            match_pre=re.compile(regex,re.DOTALL).findall(response['html'])
            
            for items in match_pre:
                if tv_movie=='tv':
                    regex='ep-item-(.+?)".+?Episode %s:'%episode_n
                else:
                    regex='ep-item-(.+?)"'
                progress='Regex4-'+str(count)
                m3=m3+re.compile(regex,re.DOTALL).findall(items)
         
           
            for items in m3:
                
                progress='Links2-'+str(count)
                url2=items.replace('\\','')
                print url2
                response = requests.get('https://www.moviesjoy.net/ajax/movie_embed/'+url2, headers=headers).json()
                progress='Check-'+str(count)
                print 'src'
                print response
                nam1,srv,res,check=server_data(response['src'],original_title)
                
                if len(response['src'])==0:
         
                    response = requests.get('https://www.moviesjoy.net/ajax/movie_sources/'+url2, headers=headers).json()
                    n2=original_title
                    print response
                    if 'tracks' in response['playlist'][0]:
                        n1=response['playlist'][0]['tracks'][0]['file']
                        n1=n1.split('/')
                        n2=n1[len(n1)-1].replace('.vtt','').replace('.srt','').replace('.ENG','')
                    for items1 in response['playlist'][0]['sources']:
                    
                        
                            all_links.append((n2.replace("%20"," "),items1['file'],'Google',items1['label']))
                            global_var=all_links
                else:
                    if check:
                            all_links.append((nam1.replace("%20"," "),response['src'],srv,res))
                            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
             