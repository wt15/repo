# -*- coding: utf-8 -*-
import requests,re,PTN,urlparse
import unjuice,time,cache,Addon

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,local
type=['tv','movie','rd']

import urllib2,urllib,logging,base64,json

color=all_colors[58]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    print 'ss'
    try:
      import resolveurl
    except:
      import resolveurl_temp as resolveurl
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    if not allow_debrid:
      return []
    all_links=[]
    if tv_movie=='tv':
      url='http://www.scnsrc.me/?s=%s'%(original_title.replace("Marvel's ",'').replace("%20","+")+'%20s'+season_n+'e'+episode_n)
    else:
      url='http://www.scnsrc.me/?s=%s'%(original_title.replace("%20","+")+'+'+show_original_year)
    import cfscrape
    print tv_movie
    print url
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    }
  
   
    tk,cook=cloudflare_request('http://www.scnsrc.me/?s=The+Flash%20s04e04')
   
    html=requests.get(url,headers=cook[1],cookies=cook[0]).content
    
    #html,cook=cloudflare.request(url,headers=headers)
    regex='<h2> <a href=(.+?) rel=bookmark title="(.+?)"><u>'
    match=re.compile(regex).findall(html)


    
    for link,title in match:
      if stop_all==1:
        break
      title=title.replace("</u>",'').replace("<u>",'').replace("  ",' ').replace("."," ").replace("'","")
     
      if tv_movie=='tv':
        if 'S%sE%s '%(season_n,episode_n) in title:
         check=True
      else:
         if show_original_year in title :
           check=True
      if clean_name(original_title,1).lower() in title.lower() and check==True:
  
          x=requests.get(link,headers=cook[1],cookies=cook[0]).content
          
          regex="<div class=comm_content><p><strong>(.+?)</p><p>(.+?)</div>"
          match_pre=re.compile(regex).findall(x)
          for name,cont in match_pre:
              regex='<a href=(.+?) rel=nofollow'
              match2=re.compile(regex).findall(cont)
              if stop_all==1:
                break
              for links in match2:
                  
                  if 'imgur.com' not in links:
                    host = links.replace("\\", "")
                    host2 = host.strip('"')
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
                  
                    if host not in rd_domains:
                        continue
                    if '.iso' in links or '.rar' in links or '.zip' in links:
                        continue
                    names=links.split('/')
                    name1=names[len(names)-1]
                    if '1080' in name1:
                          res='1080'
                    elif '720' in name1:
                          res='720'
                    elif '480' in name1:
                          res='480'
                    elif '360' in name1:
                          res='360'
                    else:
                          res='720'
              
                   
                    if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                        check1=True
                    else:
                        check1=False
                    if local:
                        check=True
                    else:
                        name1,match_s,res,check=server_data(links,original_title)
                   
                    if check  and check1:
                        all_links.append((name1,links,host,res))
                        global_var=all_links
                    
    return global_var
    
    