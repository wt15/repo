# -*- coding: utf-8 -*-
import requests,time,cache
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors

type=['movie','tv','subs']
import urllib2,urllib,logging,base64,json
try:
    Domain_sparo=Addon.getSetting("domain_sp5")
except:
    Domain_sparo='sparo.club'
color=all_colors[64]

#Domain_sparo=Addon.getSetting("domain_sp2")
def get_c(url):
    from js2py.internals import seval
    regex=",S='(.+?)'"
    s_val=re.compile(regex,re.DOTALL).findall(url)[0]

    regex="var A='(.+?)'"
    a_val=re.compile(regex,re.DOTALL).findall(url)[0]
    s={}
    L=len(s_val)
    U=0
    l=0
    a=0
    r=''
  
    for i in range(0,len(a_val)):
      s[a_val[i]]=i
    for i in range(0,len(s_val)):
     if s_val[i]!='=':
      c=s[s_val[i]]
      U=(U<<6)+c
      
      l+=6
      while (l>=8):
        l=l-8
        
        f=(U>>l)&255
        
         
        a=f;
       
        r+=chr(a);
    
   
    result2=seval.eval_js_vm(r.replace('location.reload();','').replace('document.cookie','document'))
 
    return result2,s_val

    
        
def check_cookies(url):
    from Cookie import SimpleCookie
    cookies={}
    headers = {
    'Host': Domain_sparo,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
        
    }
    x=requests.get(url, headers=headers).content
    
    if 'var s={}' in x:
      
      coockie2,token=(get_c(x))
      cookie = SimpleCookie()
      cookie.load(str(coockie2))

      # Even though SimpleCookie is dictionary-like, it internally uses a Morsel object
      # which is incompatible with requests. Manually construct a dictionary instead.
      cookies = {}
      for key, morsel in cookie.items():
            cookies[key] = morsel.value
      cookies['XSRF-TOKEN']=str(token.replace('=','%3D'))
      cookies['max-age']='86400'
    return cookies
def read_sparo_html(url):
    

    



    headers = {
    'Host': Domain_sparo,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
        
    }
    
    cookies=cache.get(check_cookies,3,'http://'+Domain_sparo, table='cookies_sp')
    
    x=requests.get(url, headers=headers,cookies=cookies).content
   
    if 'var s={}' in x :
      
      cookies=cache.get(check_cookies,0,url, table='cookies_sp')
      #cookies=check_cookies(url)
   
      x=requests.get(url, headers=headers, cookies=cookies)
      
      x.encoding = 'utf-8'
      x=x.content
   
    return x

    
def get_links(tv_movie,title,name,season_n,episode_n,season,episode,show_original_year,id):
          global global_var,stop_all
          global link_source1
          
          logging.warning('http://%s/searchlike?search='%Domain_sparo+title)
          html=read_sparo_html('http://%s/searchlike?search='%Domain_sparo+title)
         
          all_links=[]
          all_links_only=[]
          
          try:
         
            results_json=json.loads(html)
          except Exception as e:
            
            results_json=[]
            html=read_sparo_html('http://%s/searchlike?search='%Domain_sparo+name)
            try:
              results_json=json.loads(html)
            except Exception as e:
             
              results_json=[]
          
          saved_name=' '

    
          for record in results_json:
            
            if stop_all==1:
                    break
            saved_name=record['title']
            o_link='http://%s/'%Domain_sparo+record['categoria_name'].replace(' ','%20').encode('utf-8')+'/'+str(record['id'])+'/'+record['title'].replace(' ','%20').encode('utf-8')
            if tv_movie=='movie' and record['year']!=show_original_year:
                continue
            if (('series' in o_link) or ('סדרות' in o_link)) :
                new_mode=6

            else:
                new_mode=3

            season_title='עונה-%s'%season
            episode_title='פרק-%s'%episode
            if season!=None and season!='%20':
    
               html=read_sparo_html(o_link)
          
               regex1='<article>(.+?)</article>'
               match2=re.compile(regex1,re.DOTALL).findall(html)
            
               for m in match2:
                
                  if stop_all==1:
                    break
                  regex='<a href="(.+?)">'
                  match=re.compile(regex,re.DOTALL).findall(m)
                  for link in match:
                    if stop_all==1:
                        break
                    #descrp=str(plot1.strip(' \n')+'\n'+plot2.strip(' \n')+'\n[COLOR aqua]'+plot3.strip(' \n')+'[/COLOR]\n'+plot4.strip(' \n'))
                    #name_new=" ".join(name.split())
                    #name_new=name_new.replace('|'," ")
                    
                    if season_title in link :
                      
                      saved_link=link
                      break
            
               html=read_sparo_html(saved_link)
               regex1='<article>(.+?)</article>'
               match2=re.compile(regex1,re.DOTALL).findall(html)
             
               for m in match2:
                    
                    if stop_all==1:
                        break
                    regex='<a href="(.+?)">'
                    match=re.compile(regex,re.DOTALL).findall(m)
                    for link in match:
                      
                     
                      if episode_title+" @@@@@@@@" in link+"@@@@@@@@" :
                        
                        saved_link=link
                        break
            else:
                saved_link=o_link
            
        
            html=read_sparo_html(saved_link)
            regex='<a target="_blank" href="(.+?)".+?"qualityinfo">(.+?)<'
            match2=re.compile(regex,re.DOTALL).findall(html)
            
            for link,quality in match2:
                    
                    quality=quality.replace('HD','720')
                   
                    if stop_all==1:
                        break
                    html_source=read_sparo_html(link)
                    regex_source='class="btn btn-(.+?)" href="(.+?)"'
                    match_s=re.compile(regex_source).findall(html_source)
                    
                    xxx=0
                    for type,links_dip in match_s:
                        if stop_all==1:
                            break
                        match_more=[]
                       
                        if Domain_sparo in links_dip:
                          try:
                              html_source_dip=read_sparo_html(links_dip)
                             
                              
                              regex_source_dip='<iframe src="(.+?)"'
                              match_s_dip=re.compile(regex_source_dip).findall(html_source_dip)
                              regex_more='<source src="(.+?)" type="video/mp4">'
                              match_more=re.compile(regex_more,re.DOTALL).findall(html_source_dip)
                          except:
                            pass
                        else:
                          
                            regex_source_dip='class="btn btn-success" href="(.+?)"'
                            match_s_dip=re.compile(regex_source_dip).findall(html_source)
                        for in_link in match_s_dip:
                          if 'http' in in_link:
                              
                              names=re.compile('//(.+?)/',re.DOTALL).findall(in_link)[0]
                              if in_link not in all_links_only:
                                name1,match_s,res,check=server_data(in_link,saved_name)
                            
                        
                                if check :
                                    all_links_only.append(in_link)
                                    all_links.append((saved_name,in_link,names,quality))
                                    global_var=all_links
                        for links2 in match_more:
                           if stop_all==1:
                                break
                           if 'http' in links2:
                            if 'http' in links2:
                              if 'href' in links2:
                                regex_l2='href=&quot;(.+?)&quot'
                                match_le=re.compile(regex_l2).findall(links2)
                                links2=match_le[0]
                          
                              try:
                                names=re.compile('//(.+?)/',re.DOTALL).findall(links2)[0]
                              except:
                                names='Direct'
                        
                              if links2 not in all_links_only:
                                name1,match_s,res,check=server_data(links2,saved_name)
                            
                        
                                if check :
                                    all_links_only.append(links2)
                                    all_links.append((saved_name,links2,names,quality))
                                    global_var=all_links
   
          return (all_links)
