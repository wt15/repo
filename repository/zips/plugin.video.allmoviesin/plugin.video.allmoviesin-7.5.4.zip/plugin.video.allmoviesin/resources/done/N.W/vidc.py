# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,get_vidcloud
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[3]
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    if tv_movie=='movie':
        search_url=clean_name(original_title,1).replace(' ','%20')
    else:
        search_url=clean_name(original_title,1).replace(' ','%20')+'%20season%20'+season
    url='https://vidcloud.icu/search.html?keyword='+search_url
   
    progress='requests'
    time.sleep(0.01)
    html=requests.get(url,headers=base_header).content
    regex='<li class="video-block ".+?a href="(.+?)".+?div class="name">(.+?)<.+?<span class="date">(.+?)<'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
   
    count=0
    for link,name,date in match:
        print link
        progress='Links-'+str(count)
        count+=1
        if '(' in name:
            name=name.split('(')[0].strip()
        check=False
        if tv_movie=='movie':
            
            
            if clean_name(original_title,1).lower() == name.lower() and show_original_year in date:
                check=True
        else:
      
            
            if 'episode' in name:
                name1=name.split('episode')[0].strip()
            elif 'Episode' in name:
               name1=name.split('Episode')[0].strip()
            else:
                name1=name
           
            if (clean_name(original_title,1)+' -  '+'Season %s '%season ).lower().strip().replace(' ','')== name1.lower().strip().replace(' ','') :
                check=True
       
        if check:
            progress='requests-'+str(count)
            z=requests.get('https://vidcloud.icu'+link,headers=base_header).content
           
            if tv_movie=='tv':
                regex='<li class="video-block ">(.+?)</li>'
                progress='Regex2-'+str(count)
                m_pre=re.compile(regex,re.DOTALL).findall(z)
                f_link=""
              
                for items in m_pre:
                    regex='<a href="(.+?)".+?<div class="name">(.+?)</div>'
                    progress='Regex2-'+str(count)
                    m2=re.compile(regex,re.DOTALL).findall(items)
                    
                    for lk,na in m2:
                       
                        if ' Episode %s '%episode in na and clean_name(original_title,1).lower() in na.lower():
                           
                            f_link=lk
                if f_link!="":
                    z=requests.get('https://vidcloud.icu'+f_link,headers=base_header).content
                    
                else:
                    return []
           
            regex='<iframe src="(.+?)"'
            progress='Regex3-'+str(count)
            m=re.compile(regex).findall(z)[0]
            
            if 'http' not in m:
                m='http:'+m
          
            progress='requests3-'+str(count)
            lks,hdr=get_vidcloud(m)
            logging.warning('Get Vidcloud')
            for it in lks:
                name1,match_s,res,check=server_data(it,original_title)
                    
                              
                if check :
                    head=urllib.urlencode(hdr)
                    it=it+"|"+head
    
                    all_links.append((name1,it,match_s,res))
                    global_var=all_links
            y=requests.get(m,headers=base_header).content
            regex='data-video="(.+?)"'
            
            links=re.compile(regex).findall(y)
            for li in links:
                
                if 'vidcloud' in li:
                    continue
                else:
                    li=requests.get(li).url
                    if '?' in li:
                        
                        
                        li=li.split('?')[0]
                    progress='Check-'+str(count)
                    name1,match_s,res,check=server_data(li,original_title)
                    
                              
                    if check :
                        all_links.append((name1,li,match_s,'1080'))
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links