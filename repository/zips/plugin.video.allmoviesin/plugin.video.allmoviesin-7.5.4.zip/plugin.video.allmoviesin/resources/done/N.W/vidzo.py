# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[73]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    if tv_movie=='movie':
      url=domain_s+'viooz.fun/search/'+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    else:
      url=domain_s+'viooz.fun/search/'+clean_name(original_title,1).replace(' ','+')+'+s'+season_n+'e'+episode_n
    
    all_links=[]
    
    headers = {
        #'Host': 'viooz.fun',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    html=requests.get(url,headers=headers).content
    regex='<h2 class="entry-title"><a href="(.+?)".+?title="Permalink to (.+?)"'
    match=re.compile(regex).findall(html)
    for link,name1 in match:
       all_links.append((name1,link,'VZ','720'))
       global_var=all_links
    return global_var