# -*- coding: utf-8 -*-
import requests
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
global progress
progress=''
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,base_header
type=['movie','subs']

import urllib2,urllib,logging,base64,json
color=all_colors[68]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    progress='requests'
    html=requests.get('https://www.dantv.ga/search?q='+clean_name(original_title,1).replace(' ','+'),headers=base_header).content
    regex="<a class='post-image-link' href='(.+?)'"
    progress='Regex'
    m=re.compile(regex).findall(html)[0]
    progress='requests2'
    y=requests.get(m,headers=base_header).content
    regex='iframe.+?src="(.+?)"'
    link=re.compile(regex).findall(y)[0]
    if 'cloudvideo.tv' in link:
        y=requests.get(link,headers=base_header).content
        regex='source src="(.+?)"'
        link=re.compile(regex).findall(y)[0]
        
        
        res='0'
        all_links.append((original_title,link,'Direct',res))
        
        global_var=all_links
            
    elif 'cdn.jwplayer.com' in link:      
        links=link.split('/')
        f_link=links[len(links)-1]
        f_link2=f_link.split('-')[0]
        url='https://content.jwplatform.com/v2/media/'+f_link2
        y=requests.get(url,headers=base_header).json()
        for it in y['playlist']:
           for items in it['sources']:
            if 'width' in items:
                res=str(items['width'])
            else:
                res='0'
            all_links.append((original_title,items['file'],'Direct',res))
        
            global_var=all_links

        
    else:
        progress='Check'
        name1,match_s,res,check=server_data(link,original_title)
                        
        if check:
              all_links.append((name1.replace("%20"," "),link,match_s,res))
        
              global_var=all_links

    

    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    