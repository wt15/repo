# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[19]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        
        

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0',
            'TE': 'Trailers',
        }
        all_links=[]
        base_link = domain_s+'openloadmovie.org'
        search_id=clean_name(original_title,1)
       
        movie_link = '%s/movies/%s-%s/' %(base_link,search_id.replace(' ','-'),show_original_year)

        html,cook = cloudflare_request(movie_link,headers=headers)
        links = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(html)
        count = 0
        
        for i in range(0,5):
            if ' 523: Origin is unreachable' in html:
                time.sleep(0.1)
             
                
            else:
                
                links = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(html)
                break
            html,cook = cloudflare_request(movie_link,headers=headers)
        for link in links:                
            if stop_all==1:
                break
            if 'youtube' not in link:   
                if '1080p' in link:
                    qual = '1080p'
                elif '720p' in link:
                    qual='720p'
                else:
                    qual='SD'

                host = link.split('//')[1].replace('www.','')
                host = host.split('/')[0].split('.')[0].title()
                count +=1
                #self.sources.append({'source': host,'quality': qual,'scraper': self.name,'url': link,'direct': False})
                
                name1,match_s,res,check=server_data(link,original_title)
                
                if check:
                   all_links.append((name1,link,match_s,qual))
                   global_var=all_links
        return global_var