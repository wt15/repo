# -*- coding: utf-8 -*-
import requests,PTN,urlparse
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[20]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    
    
    
    all_links=[]
    
    headers = {
        
        'accept-encoding': 'utf8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
        'accept': 'application/json, text/javascript, */*; q=0.01',
        
        'authority': 'moon.egybest.org',
        'x-requested-with': 'XMLHttpRequest',
    }

    params = (
        ('q', clean_name(original_title,1)),
    )

    response = requests.get('https://moon.egybest.org/autoComplete.php', headers=headers, params=params).json()
    
    for key in response:
      
      if stop_all==1:
           break
      for items in response[key]:
         
         if stop_all==1:
            break
         check=False
         if tv_movie=='tv':
            if clean_name(original_title,1).lower() == items['t'].lower():
                check=True
         elif show_original_year in items['t'] and  clean_name(original_title,1).lower() in items['t'].lower():
            check=True
         
         if check :
           
             if tv_movie=='tv':
                 cl_name=items['u'].replace('series','').replace('/','')
                 new_url=domain_s+'moon.egybest.org/episode/%s-season-%s-ep-%s/'%(cl_name,season,episode)
             else:
                 cl_name=items['u'].replace('movie','').replace('/','')
                 new_url=domain_s+'moon.egybest.org/movie/%s/'%(cl_name)
             
          
             headers_pre = {
                'authority': 'moon.egybest.org',
                'pragma': 'no-cache',
                'cache-control': 'no-cache',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
                'sec-fetch-mode': 'navigate',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                'sec-fetch-site': 'none',
                'accept-encoding': 'utf-8',
                'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               
             }
             x=requests.get(new_url,headers=headers_pre).content
            
             regex='<td>(.+?)<i class=".+?"></i></td><td>(.+?)</td>.+?data-url="(.+?)"'
             time.sleep(0.1)
             match2=re.compile(regex,re.DOTALL).findall(x)
             for q,size_p,lk in match2:
                xx= lk.replace('api?','')
                zz={yy.split('=')[0]:(yy.split('=')[1]) for yy in xx.split("&")}
                
                headers = {
                    'authority': 'moon.egybest.org',
                    'pragma': 'no-cache',
                    'cache-control': 'no-cache',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
                    'sec-fetch-mode': 'navigate',
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                    'sec-fetch-site': 'none',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                    
                }

                params = (
                    ('call',zz['/call']),
                    ('auth', zz['auth']),
                )
                
                #response = requests.get('https://moon.egybest.org/api', headers=headers, params=params).url
         
               
                x=requests.get(domain_s+'moon.egybest.org'+lk,headers=headers).url
               
                nam1,srv,res,check=server_data(x,original_title)
                          
                if check:
                     if 'MB' in size_p:
                            size=str(round(float(size_p.replace('MB',''))/1024, 2))+' GB'
                     else:
                            size=size_p.replace('GB','')+' GB'
                     res=res_q(q)
                     all_links.append((nam1,x,srv+' - '+size,res))
                     global_var=all_links
    return global_var