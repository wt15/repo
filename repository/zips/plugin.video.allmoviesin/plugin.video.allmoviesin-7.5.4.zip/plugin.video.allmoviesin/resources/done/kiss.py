# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[1]
def resolve_kiss(url,original_title,all_links):
    global global_var
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': url,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }

    data = {
      'r': '',
      'd': 'kissmovies.xyz'
    }

    response = requests.post(url.replace('/v/','/api/source/'), headers=headers, data=data).json()
    for items in response['data']:
        name2,match_s,res,check=server_data(items['file'],original_title)
                
                
        if check:
           
            all_links.append((name2,items['file'],match_s,items['label'].replace('p','')))
            global_var=all_links
           
    
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    if tv_movie=='movie':
        url='https://kissmovies.net/search/%s.html'%(clean_name(original_title,1).lower().replace(' ','-'))
    else:
        url='https://kissmovies.net/search/%s.html'%(clean_name(original_title,1).lower().replace(' ','-')+'-'+season)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    
    
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
    progress='requests'
    x=requests.get(url,headers=headers).content
    
    regex='<div class="movie_wrapper_fix">.+?<a href="(.+?)".+?<h2>(.+?)<.+?<div class="jt-info">(.+?)<'
    progress='Regex'
    m=re.compile(regex,re.DOTALL).findall(x)
    count=0
    for link,title,year in m:
        progress='Links-'+str(count)
        count+=1
        check=False
        if tv_movie=='tv':
            if '(' in title:    
                c_title=title.split('(')[0].strip()
               
                if c_title.lower()==clean_name(original_title,1).lower()+' '+season:
                    check=True
        else:
            if year==show_original_year:
                check=True
        if  (clean_name(original_title,1).lower() not in title.lower()) or check==False:
            continue
        
        y=requests.get('https://kissmovies.net/'+link,headers=headers).content
        regex='id: "(.+?)",.+?name: "(.+?)"'
        info=re.compile(regex,re.DOTALL).findall(y)[0]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://kissmovies.net/'+link,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
        }

        data = {
          'id': info[0],
          'n': info[1]
        }

        response = requests.post('https://kissmovies.net/ajax/loadsv/'+info[0], headers=headers,  data=data).json()
        
        for items in response:
            progress='Links2-'+str(count)
            if (items['episodeName']!=episode_n) and tv_movie=='tv':
                continue
   
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': 'https://kissmovies.net/'+items['episodeUrl'],
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'TE': 'Trailers',
            }

            data = {
              'epid': items['episodeId']
            }

            response2 = requests.post('https://kissmovies.net/ajax/loadep/'+items['episodeId'], headers=headers, data=data).json()
           
            regex='src="(.+?)"'
            links=re.compile(regex,re.DOTALL).findall(response2["link"]['embed'])[0]
            progress='Check-'+str(count)
            if 'kiss' in links:
                u=resolve_kiss(links,original_title,all_links)
            else:
                name2,match_s,res,check=server_data(links,original_title)
                
                
                if check:
                   
                    all_links.append((name2,links,match_s,res))
                    
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    