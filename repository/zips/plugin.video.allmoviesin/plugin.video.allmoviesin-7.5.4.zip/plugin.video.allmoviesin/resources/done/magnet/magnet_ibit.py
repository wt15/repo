# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
try:
    from general import Addon
except:
  import Addon
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json

color=all_colors[110]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year
      s_type='Movies'
    else:
      search_url=clean_name(original_title,1).replace(' ','%20')+'%20s'+season_n+'e'+episode_n
      s_type='TV'
  
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    
    all_links=[]
    
    for page in range(1,7):
        
        x=requests.get('https://ibit.to/torrent-search/%s/all/score:desc/%s/'%(search_url+'%202160',str(page)),headers=base_header).content
        
        regex_pre='<tr>(.+?)</tr>'
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        for items in m_pre:
            regex='a href="(.+?)" title="(.+?)".+?class="digits">(.+?)<.+?data-title="S">(.+?)<.+?data-title="L">(.+?)<'
            macth_pre=re.compile(regex,re.DOTALL).findall(items)
            if stop_all==1:
                break
        
                
                
            for link,title,size,seed,peer in macth_pre:
                        
                         if clean_name(original_title,1).lower() not in title.lower().replace('.',' '):
                            continue
                         if stop_all==1:
                            break
                         if '4k' in title:
                              res='2160'
                         elif '2160' in title:
                              res='2160'
                         elif '1080' in title:
                              res='1080'
                         elif '720' in title:
                              res='720'
                         elif '480' in title:
                              res='480'
                         elif '360' in title:
                              res='360'
                         else:
                              res='HD'
                        
                         o_link=link
                       
                         try:
                             o_size=size
                             size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                             if 'MB' in o_size:
                               size=size/1000
                         except Exception as e:
                            
                            size=0
                         max_size=int(Addon.getSetting("size_limit"))*100
                        
                         if size<max_size:
                           
                           if allow_debrid:
                                x=requests.get('https://ibit.to'+o_link,headers=base_header).content
                                regex="magnet\:(.+?)'"
                                mm=re.compile(regex).findall(x)
                                lk='magnet:'+mm[0].decode("string-escape").replace('X-X','')
                           else:
                                lk='https://ibit.to'+o_link
                           all_links.append((title,lk,'- Ibit - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                       
                           global_var=all_links
                        
                            
    for page in range(1,7):
        if stop_all==1:
            break
        x=requests.get('https://ibit.to/torrent-search/%s/all/score:desc/%s/'%(search_url,str(page)),headers=base_header).content
       
        regex_pre='<tr>(.+?)</tr>'
        m_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        for items in m_pre:
            if stop_all==1:
                break
            regex='a href="(.+?)" title="(.+?)".+?class="digits">(.+?)<.+?data-title="S">(.+?)<.+?data-title="L">(.+?)<'
            macth_pre=re.compile(regex,re.DOTALL).findall(items)
            
        
                
                
            for link,title,size,seed,peer in macth_pre:
                         if stop_all==1:
                            break
                         if clean_name(original_title,1).lower() not in title.lower().replace('.',' '):
                            continue
                         if stop_all==1:
                            break
                         if '4k' in title:
                              res='2160'
                         elif '2160' in title:
                              res='2160'
                         elif '1080' in title:
                              res='1080'
                         elif '720' in title:
                              res='720'
                         elif '480' in title:
                              res='480'
                         elif '360' in title:
                              res='360'
                         else:
                              res='HD'
                        
                         o_link=link
                       
                         try:
                             o_size=size
                             size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                             if 'MB' in o_size:
                               size=size/1000
                         except Exception as e:
                            
                            size=0
                         max_size=int(Addon.getSetting("size_limit"))
                        
                         if size<max_size:
                           if allow_debrid:
                                x=requests.get('https://ibit.to'+o_link,headers=base_header).content
                                regex="magnet\:(.+?)'"
                                mm=re.compile(regex).findall(x)
                                lk='magnet:'+mm[0].decode("string-escape").replace('X-X','')
                           else:
                                lk='https://ibit.to'+o_link
                           all_links.append((title,lk,'- Ibit - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
                       
                           global_var=all_links
    return global_var
        
    