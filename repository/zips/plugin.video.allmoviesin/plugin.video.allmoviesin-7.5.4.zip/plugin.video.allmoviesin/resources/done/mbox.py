# -*- coding: utf-8 -*-
#taken from CARTOON HD movies
import requests,PTN
import hashlib
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,res_q
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[62]

def decrypt(ti,data_j):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'https://www.devglan.com/online-tools/aes-encryption-decryption',
        'Content-Type': 'application/json;charset=utf-8',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    data = {'textToDecrypt':data_j,
            'secretKey':ti,
            'mode':'ECB',
            'keySize':'128',
            'dataFormat':'Base64',
      
    }

    response = requests.post('https://www.devglan.com/online-tools/aes-decryption', headers=headers, json=data).json()
    
    try:
        return json.loads(response['output'].decode('base64'))
    except:
        return response['output'].decode('base64')

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    import hashlib 
    progress='Start'
    start_time=time.time()
    all_links=[]
    version='1.0.5'
    versioncode='105'
    extra_1='3E9200A7FAE3C77A4A7B8B97CD518224'
    ti=int(time.time())
    headers_p={'Content-Type': 'application/x-www-form-urlencoded',

            'Connection': 'Keep-Alive',
            'User-Agent': 'Apache-HttpClient/UNAVAILABLE (java 1.4)'}
    
    data={'select':'search',
    'q':original_title,
    'page':'1',
    'total':'0',
    'os':'android',
    'version':version,
    'versioncode':versioncode,
    'extra_1':extra_1,
    'deviceid':'xxxxxxxxxxxxxxxx',
    'access_token':'Y2Q0ODk2MGMzYTQ0ZDE0NTMyOTBkNGRjYzRhNzZjNTU%3D%0A'}
    
    
    
    
            
    progress='requests'
    html=requests.post('http://megaboxhd.com/megaboxhd/android_api_105_n/index2.php',headers=headers_p,data=data).content
   
    code=versioncode + version + extra_1
    
    
    
    ti_f=str(hashlib.md5(str(code)).hexdigest()) .lower()[0:16]
    progress='decrypt'
    
    result=decrypt(ti_f,html)
    
    data_j=(result)
    
    for items in result['categories']:
        
        if clean_name(original_title,1).lower() in items['catalog_name'].lower() and show_original_year in items['catalog_name']:
            sid=str(hashlib.md5("content" + items['catalog_id'] + "cthd").hexdigest()) .lower()
            
            
            
            
            data={'select':'detail',
            'id':items['catalog_id'],
            'os':'android',
            'version':version,
            'versioncode':versioncode,
            'extra_1':extra_1,
            'deviceid':'1f77ababbb9e04de',
            'devicename':'xxxxxxxx',
            'access_token':'Y2Q0ODk2MGMzYTQ0ZDE0NTMyOTBkNGRjYzRhNzZjNTU%3D%0A'}
            
            
                    
            progress='requests2'
            html=requests.post('http://megaboxhd.com/megaboxhd/android_api_105_n/index2.php',headers=headers_p,data=data).content
            
            progress='decrypt2'
            result=decrypt(ti_f,html)
           
            data_j=result
            for it in result['listvideos']:
                if tv_movie=='tv':
                    if 'S%sE%s'%(season_n,episode_n) not in it['film_name']:
                        continue
               
                sid=str(hashlib.md5(it['film_id'] + items['catalog_id'] + "cthd").hexdigest()) .lower()
                
                
                data={'select':'stream',
                'id':it['film_id'],
                'cataid':items['catalog_id'],
                'os':'android',
                'version':version,
                'versioncode':versioncode,
                'extra_1':extra_1,
                'deviceid':'1f77ababbb9e04de',
                'devicename':'xxxxxxxxxxxx',
                'access_token':'Y2Q0ODk2MGMzYTQ0ZDE0NTMyOTBkNGRjYzRhNzZjNTU%3D%0A'}

               
                        
                progress='requests3'
                html=requests.post('http://megaboxhd.com/megaboxhd/android_api_105_n/index2.php',headers=headers_p,data=data).content

                
                result=decrypt(ti_f,html)
                key=str(hashlib.md5(str(code)).hexdigest()) .lower()[5:21]
                
                progress='decrypt3'
          
                link=decrypt(key,result['videos'][0]['film_link']).replace('\n','')
               
                regex='http(.+?)#(.+?)#'
                links=re.compile(regex).findall(link)
                for link_in,q in links:
                    if 'http' not in link_in:
                        link_in='http'+link_in
                    all_links.append((original_title.replace("%20"," "),link_in,'Direct',q))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
                    
        
           