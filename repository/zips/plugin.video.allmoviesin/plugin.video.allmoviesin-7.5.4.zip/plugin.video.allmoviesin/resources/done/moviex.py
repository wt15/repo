import requests
import unjuice,time
global progress
progress=''
global global_var#global
global_var=[]
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s,cloudflare_request

type=['movie']
import urllib2,urllib,logging,base64,json
color=all_colors[45]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,progress
    all_links=[]
    progress='Start'
    start_time=time.time()
    import urllib2
    sUrl='http://moviexk.co/search/'+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
   
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    import json,urllib

    progress='Cloud'
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    user_agent="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    x,token=cloudflare_request(sUrl)

    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    progress='requests'
    html= requests.get(sUrl,cookies=token[0],headers=headers).content 

    regex='<div class="inner">.+?<a href="(.+?)"'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
    progress='requests'
    y=requests.get(match[0],cookies=token[0],headers=headers).content  

    regex='data-type="watch" class="" href="(.+?)"'
    progress='Regex2'
    match=re.compile(regex,re.DOTALL).findall(y)
    if len(match)==0:
        regex='btn-groups fr.+?<a href="(.+?)"'
        progress='Regex3'
        match=re.compile(regex,re.DOTALL).findall(y)
    progress='requests2'
    y=requests.get(match[0],cookies=token[0],headers=headers).content  
    
    
    
    regex='<iframe.+?src="(.+?)"'
    progress='Regex4'
    match=re.compile(regex,re.DOTALL).findall(y)
    t=requests.get(match[0],cookies=token[0],headers=headers).content  
    
    regex='<iframe.+?src="(.+?)"'
    progress='Regex4'
    match=re.compile(regex,re.DOTALL).findall(t)
    
    if len(match)>0:
        ids=match[0].split('/')
        id=ids[len(ids)-1]
        if 'vcstream' in match[0]:
           url=domain_s+'vcstream.to/player?fid=%s&page=embed'%id
           progress='requests3'
           tt=requests.get(url,headers=headers).content
           regex='player.updateSrc\((.+?)\)'
           progress='Regex5'
           match2=re.compile(regex,re.DOTALL).findall(tt)

           links=json.loads(match2[0].replace('\\\\','').replace('\\"','"'))

          
           for items in links:
                 if stop_all==1:
                    break
                 res=items['label']
                 name_in=items['name']
                 link_f=items['src']
               
                 
                 all_links.append((name_in.replace("%20"," "),link_f,'Direct',res))
                 global_var=all_links
        elif 'entervideo' in match[0]:
                            y=requests.get(match[0],headers=headers).content
                            regex='source src="(.+?)"'
                            f_link=re.compile(regex).findall(y)
                            
                            
                            names=f_link[0].split('/')
             
                            name1=names[len(names)-1]
                            if "1080" in name1:
                                res="1080"
                            elif "720" in name1:
                                res="720"
                            elif "480" in name1:
                                res="720"
                            elif "hd" in name1.lower():
                                res="HD"
                            else:
                               res=' '
                            headers2 = {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Cache-Control': 'no-cache',
                            'Connection': 'keep-alive',
                            'Host': 'entervideo.net',
                            'Pragma': 'no-cache',
                            'Referer':match[0],
                            'Upgrade-Insecure-Requests': '1',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                            }
                            head=urllib.urlencode(headers2)
                            all_links.append((name1,f_link[0]+"|"+head,'Direct',res))
                            global_var=all_links
        else:
            progress='Check'
            nam1,srv,res,check=server_data(match[0],original_title)
                      
            if check:
                    all_links.append((nam1.replace("%20"," "),match[0],srv,res))
                    global_var=all_links
    regex='<source src="(.+?)".+?data-res="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(t)
    for link,res in match:
        all_links.append((original_title,link,'Google',res))
        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links