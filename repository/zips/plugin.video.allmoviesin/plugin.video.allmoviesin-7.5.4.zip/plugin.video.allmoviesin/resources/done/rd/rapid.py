# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,Addon

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie','rd']

import urllib2,urllib,logging,base64,json
color=all_colors[53]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
  global global_var,stop_all

  rd_sources=Addon.getSetting("rdsource")
  allow_debrid = rd_sources == "true" 
  if not allow_debrid:
      return []
  all_links=[]
  headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'search.rlsbb.ru:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
  x=requests.get('http://www.rapidgatorsearch.com/',headers=headers).content
  regex="var cx = '(.+?)'"
  match=re.compile(regex).findall(x)
  cx=match[0]
  
  x=requests.get(domain_s+'cse.google.com/cse.js?cx='+cx).content
  regex='"cse_token": "(.+?)"'
  match=re.compile(regex).findall(x)
  cse=match[0]
  if tv_movie=='movie':
    q=(original_title.replace('%20',' ')+' '+show_original_year)
  else:
    q=(original_title.replace('%20',' ').replace('%27','')+' s'+season_n+' e'+episode_n)
  
  headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'http://www.rapidgatorsearch.com/',
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }
  '''
  params = (
        ('rsz', 'filtered_cse'),
        ('num', '10'),
        ('hl', 'en'),
        ('source', 'gcsc'),
        ('gss', '.com'),
        ('cx', '004238030042834740991:a507rbxtjn0'),
        ('q', 'rampage 2018'),
        ('safe', 'off'),
        ('cse_tok', 'AKaTTZg6KxLJ1qOXLWlXhoDk3_rU:1545064539353'),
        ('sort', ''),
        ('oq', 'rampage 2018'),
        ('gs_l', 'partner-generic.12...108315.108929.2.118665.5.5.0.0.0.0.260.737.2j2j1.5.0.gsnos,n=13...0.569j109507j5...1.34.partner-generic..12.0.0.mIBLcz9BELM'),
        ('callback', 'google.search.cse.api12194'),
    )
  '''


  headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'http://www.rapidgatorsearch.com/',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
  }

  params = (
    ('rsz', 'filtered_cse'),
    ('num', '10'),
    ('hl', 'en'),
    ('source', 'gcsc'),
    ('gss', '.com'),
    ('cx', cx),
    ('q', q),
    ('safe', 'off'),
    ('cse_tok', cse),
    ('sort', ''),
    ('oq', q),
    
    ('callback', 'google.search.cse.api12194'),
  )
  
  html = requests.get('https://cse.google.com/cse/element/v1', headers=headers, params=params).content


  regex='google.search.cse.api12194\((.+?)\);'
  match=json.loads(re.compile(regex,re.DOTALL).findall(html)[0])
  
  
  for items in match['results']:
     if 'titlt' in items:
        na=items['title']
     else:
        na=items['unescapedUrl']
     if '.rar' not in na.replace(' ','.').replace('<b>','').replace('</b>','').lower() and '.rar' not in items['url'] and clean_name(original_title,1).replace(' ','.').lower() in na.replace(' ','.').replace('<b>','').replace('</b>','').lower():
        link=items['url']
        if '.iso' in link or '.rar' in link or '.zip' in link:
            continue
        names=link.split('/')
        name1=names[len(names)-1]
        if '1080' in name1:
              res='1080'
        elif '720' in name1:
              res='720'
        elif '480' in name1:
              res='480'
        elif '360' in name1:
              res='360'
        else:
              res='720'
        if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
            check1=True
        else:
            check1=False
        name1,match_s,res,check=server_data(items['url'],original_title,direct='rd')
        if check and check1:
            all_links.append((name1.replace('Download file','').strip(),items['url'],'rapidgator',res))
            global_var=all_links
  return global_var
  