import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[78]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    
    
    if tv_movie=='tv':
      url=domain_s+'watchvideo.us/?op=search&k='+(original_title.replace("Marvel's ",'').replace("%20","+")+'%20s'+season_n+'e'+episode_n).replace('%20','+').replace(' ','+')
    else:
      url=domain_s+'watchvideo.us/?op=search&k='+(original_title.replace("%20","+")+'+'+show_original_year).replace('%20','+').replace(' ','+')
    all_links=[]
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    #'Host': 'vidfast.co',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
  
    html=requests.get(url,headers=headers).content
 
    regex='<a href="(.+?)" class="title">(.+?)<'
    match=re.compile(regex).findall(html)

    for link,title in match:
       if stop_all==1:
         break
       if tv_movie=='tv':
        if 's%se%s '%(season_n,episode_n) in title.lower():
         check=True
       else:
         if show_original_year in title :
           check=True
       
       if clean_name(original_title,1).lower() in title.lower() and check==True:
    
        x=requests.get(link,headers=headers).content
        print link
        #names=link.split('/')
        #name1=names[len(names)-1]
        regex_n='<h2>(.+?)</h2>'
        name1=re.compile(regex_n,re.DOTALL).findall(x)[0].strip()
     
        regex='download_video\((.+?)\)">.+?</a></td><td>.+?x(.+?),'
        match2=re.compile(regex).findall(x)
        all_links_in=[]
        
        for items in match2:
         
            if stop_all==1:
                break
            data=items[0].split(",")
            if int(items[1])<=480:
               quality='480'
            elif int(items[1])>=480 and int(items[1])<=720:
              quality='720'
            elif int(items[1])>=720:
              quality='1080'
            
            link2=domain_s+'watchvideo.us/dl?op=download_orig&id=%s&mode=%s&hash=%s'%(data[0].replace("'",''),data[1].replace("'",''),data[2].replace("'",''))


            if link2 not in all_links_in:
               
                all_links_in.append(link2)
                
                y=requests.get(link2,headers=headers).content
                while 'Generating download link...' in y:
                  time.sleep(0.1)
                  y=requests.get(link2,headers=headers).content
                regex='a href="(.+?)">Direct Download Link<'
                
                match3=re.compile(regex).findall(y)[0]
        
                f_pars=match3.split('/')
                fpart=f_pars[len(f_pars)-1]
                print match3
                a=a+1
                match3=match3.replace('.us/','.us/hls/').replace(fpart,'master.m3u8')
                
                all_links.append((name1,match3,'Direct',quality))
                global_var=all_links
     
    return global_var
            
         
         
         
      
      