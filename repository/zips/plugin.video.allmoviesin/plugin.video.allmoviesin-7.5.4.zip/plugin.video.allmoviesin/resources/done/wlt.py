# -*- coding: utf-8 -*-
import requests
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
global progress
progress=''
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,base_header
type=['tv','subs']

import urllib2,urllib,logging,base64,json
color=all_colors[68]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    progress='requests'
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://www.willtv.net',
        'Connection': 'keep-alive',
        'Referer': 'https://www.willtv.net/searchlist.php',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    data = {
      'keyword': clean_name(original_title,1)
    }

    response = requests.post('https://www.willtv.net/searchlist.php', headers=headers, data=data).content
    regex='<li><a href="(.+?)" title="Watch free (.+?) "'
    m=re.compile(regex).findall(response)
   
    for lk,it in m:
       
        if clean_name(original_title,1).lower()==it.lower():
            x=requests.get('https://www.willtv.net'+lk,headers=base_header).content
            regex='<div class="cut-list">(.+?)</div>'
            m2=re.compile(regex,re.DOTALL).findall(x)
            regex='<li>S&nbsp;(.+?)&nbsp; ,&nbsp;Ep(.+?)&nbsp;.+?href="(.+?)"'
            m3=re.compile(regex,re.DOTALL).findall(m2[0])
            
            for se,ep,lkk in m3:
                
                if se==season and ep==episode_n:
                    
                    y=requests.get('https://www.willtv.net'+lkk,headers=base_header).content
                    regex='<source src="(.+?)"'
                    f_link2=re.compile(regex,re.DOTALL).findall(y)[0]
                    f_link='https://www.willtv.net'+lkk
                    try_head = requests.head(f_link2,headers=base_header, stream=True,verify=False,timeout=15)
                  
                    check=(try_head.headers)
                    if int(check['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(check['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Direct'+' - '+f_size2
                    else:
                        s_name='Direct'
                    break
    all_links.append((original_title.replace("%20"," "),f_link,s_name,'720'))

    global_var=all_links

    

    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    