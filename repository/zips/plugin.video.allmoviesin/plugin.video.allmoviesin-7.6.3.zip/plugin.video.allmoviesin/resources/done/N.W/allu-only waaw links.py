# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[105]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
   

    
    all_links=[]
    if tv_movie=='tv':
        search_string=clean_name(original_title,1).replace(' ','+')+'+s'+season_n+'e'+episode_n
    else:
        search_string=clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    x=requests.get('https://w1.alluc.uno/?s='+search_string,headers=base_header).content

    regex='a class="masterTooltip " href="(.+?)" title="(.+?)"'
    m=re.compile(regex).findall(x)
    
    
    for link,title in m:
        check=False
        if tv_movie=='tv':
            check=True
        else:
            if show_original_year in title:
                check=True
        if clean_name(original_title,1).lower() in title.lower() and check:
            
            y=requests.get(link,headers=base_header).content
            regex="str='(.+?)'"
            m=re.compile(regex).findall(y)[0]
            b=m.replace('@', '%')
            c=urllib.unquote_plus(b)
            regex='src="(.+?)"'
            m=re.compile(regex).findall(c)[0]
            z=requests.get(m,headers=base_header).content
            time.sleep(5)
            regex='name="_csrfToken" autocomplete="off" value="(.+?)"'
            csrfToken=re.compile(regex).findall(z)[0]
            regex='name="ad_form_data" value="(.+?)"'
            ad_form_data=re.compile(regex).findall(z)[0]
            
            regex='name="_Token\[fields\]" autocomplete="off" value="(.+?)"'
            _Token_f=re.compile(regex).findall(z)[0]
            
            regex='name="_Token\[unlocked\]" autocomplete="off" value="(.+?)"'
            _Token_u=re.compile(regex).findall(z)[0]
            
            cookies = {
               
               
                'csrfToken': csrfToken,
                
                
                
            }

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': m,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'TE': 'Trailers',
            }

            data = {
              '_method': 'POST',
              '_csrfToken': csrfToken,
              'ad_form_data': ad_form_data,
              '_Token[fields]': _Token_f,
              '_Token[unlocked]': _Token_u
            }
            data = {
              '_method': 'POST',
              '_csrfToken':csrfToken,
              'ad_form_data': ad_form_data,
              '_Token[fields]': _Token_f.strip(),
              '_Token[unlocked]': _Token_u
            }
            
            response = requests.post('https://event.2target.net/links/go', headers=headers, cookies=cookies, data=data).json()
      
            name2,match_s,res,check=server_data(response['url'],original_title)
           
            if check:

                all_links.append((name2,response['url'],match_s,res))
                
                global_var=all_links
    return all_links
