# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[24]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    headers = {
                                
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
                            
    base_link='http://freemoviedownloads6.com'
    scrape = clean_name(original_title,1).replace(' ','+')
    
    start_url = domain_s+'www.google.co.uk/search?q=freemoviedownloads6.com+%s+%s' %(scrape,show_original_year)
   
    

    html = requests.get(start_url,headers=headers,timeout=3).content

    results = re.compile('href="(.+?)"',re.DOTALL).findall(html)
    for url in results: 
        if base_link in url :

            if scrape.replace('+','-') in url:
                if 'webcache' in url:
                    continue
                confirm_name = clean_name(original_title,1) +' '+ show_original_year 

            
           
                OPEN = requests.get(url,headers=headers,timeout=5).content
                
                getTit = re.compile('<title>(.+?)</title>',re.DOTALL).findall(OPEN)[0]
                getTit = getTit.split('Free')[0]
          
                if getTit.lower().strip() == confirm_name.lower().strip():
          
                    OPEN = OPEN.split("type='video/mp4'")[1]
                    Regex = re.compile('href="(.+?)"',re.DOTALL).findall(OPEN)
             
                    for link in Regex:
                       
                        if '1080' in link:
                            res = '1080p'
                        elif '720' in link:
                            res = '720p'
                        elif '480' in link:
                            res = '480p'
                        else:
                            res = 'SD'                
                        regex='//(.+?)/'
                        match_s=re.compile(regex).findall(link)[0]
                        ids=link.split('/')
                        name1=ids[len(ids)-1]
                        if '.mkv' in link:
                            
                                  
                                  all_links.append((name1.replace("%20"," "),link,match_s,res))
                                  global_var=all_links
                            #self.sources.append({'source': 'DirectLink', 'quality': res, 'scraper': self.name, 'url': link,'direct': True})
                        if '.mp4' in link:
                           
                                  all_links.append((name1.replace("%20"," "),link,match_s,res))
                                  global_var=all_links
                            #self.sources.append({'source': 'DirectLink', 'quality': res, 'scraper': self.name, 'url': link,'direct': True})
    return global_var