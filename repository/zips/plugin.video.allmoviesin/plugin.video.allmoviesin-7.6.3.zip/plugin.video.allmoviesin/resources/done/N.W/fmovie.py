import requests
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,parseDOM,cloudflare_request
type=['movie','tv']

import urllib2,urllib,logging,base64,json,urlparse
color=all_colors[83]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    



 

    global global_var,stop_all

    all_links=[]
    base_link='http://fmovies.top'
    clean_title=clean_name(original_title,1)
    
    query = ('/search/%s.html'  % clean_name(original_title,1))
   
    url = urlparse.urljoin(base_link, query).replace(' ','+')
    print url
    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    search_response,cook = cloudflare_request(url)
    regex='<div class="ml-item">(.+?)div class="clearfix"'
    m_pre=re.compile(regex,re.DOTALL).findall(search_response)
    print m_pre
    for it in m_pre:
        regex='<a href="(.+?)".+?<span class="mli-info"><h2>(.+?)<.+?div class="jt-info">(.+?)<'
        m_pre=re.compile(regex,re.DOTALL).findall(it)
      
        for link,nm,yr in m_pre:
            check=False
            if tv_movie=='tv':
                if 'S%s'%season_n not in nm:
                    continue
                check=True
            else:
                if yr==show_original_year:
                    check=True
            
            if check and clean_name(original_title,1).lower() in nm.lower():
                search_response,cook = cloudflare_request(link)
                quality = re.findall(">(\w+)<\/p",search_response)
                if quality[0] == "HD":
                    quality = "720p"
                else:
                    quality = "SD"
                
                if tv_movie=='tv':
                    regex='<a class="episode_%s btn-eps first-ep" href="(.+?)"'%episode
                    m2=re.compile(regex).findall(search_response)
                    if len(m2)==0:
                        continue
                    search_response,cook = cloudflare_request(m2[0])
                    regex_p='<div id="servers-list(.+?)</a></li></ul></div>'
                    m22=re.compile(regex_p).findall(search_response)
                    regex='data-film="(.+?)" data-name="(.+?)" data-server="(.+?)"'
                    m=re.compile(regex).findall(m22[0])
                else:
                    regex='data-film="(.+?)" data-name="(.+?)" data-server="(.+?)"'
                    m=re.compile(regex).findall(search_response)
                
                
                for dd_film,dd_name,dd_server in m:
                    post = {'ipplugins': 1,'ip_film': dd_film, 'ip_server': dd_server, 'ip_name': dd_name,'fix': "0"}
                    headers={
                    'Referer':url,
                    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                    }
                    p1,ck = cloudflare_request('http://fmovies.sc/ip.file/swf/plugins/ipplugins.php', post=post)
                    p1=json.loads(p1)
                    p2,ck = cloudflare_request('http://fmovies.sc/ip.file/swf/ipplayer/ipplayer.php?u=%s&s=%s&n=0' %(p1['s'],dd_server))
                    print p2
                    p2 = json.loads(p2)
                    p3,ck = cloudflare_request('http://fmovies.sc/ip.file/swf/ipplayer/api.php?hash=%s' %(p2['hash']))
                    p3 = json.loads(p3)
                    n = p3['status']
                    if n == False:
                            p2,ck = cloudflare_request('http://fmovies.sc/ip.file/swf/ipplayer/ipplayer.php?u=%s&s=%s&n=1' %(p1['s'],dd_server))
                            p2 = json.loads(p2)
                    url =  "%s" %p2 ["data"].replace("\/","/")
             
                    name1,match_s,res,check=server_data(url,original_title)
                  
                    if check:
                        if res==' ':
                            res=quality
                    
                        all_links.append((name1.replace("%20"," "),url,match_s,res))                
                                
                        global_var=all_links
           
    
    
    return global_var
