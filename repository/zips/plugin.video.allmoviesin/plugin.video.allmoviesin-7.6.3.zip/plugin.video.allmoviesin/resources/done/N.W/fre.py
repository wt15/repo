# -*- coding: utf-8 -*-
#Taken from cinemax 2019/replaced by hd movies play
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[2]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    #import cfscrape
    all_links=[]






    url='http://104.237.1.48/freehd/api.php?kod=net.freemovieplay.gooddaymovies&search='+(original_title)
    headers={'Cookie': 'PHPSESSID=9nsf7sp3u43ncjpsjna1uilse4',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; Le X526 Build/IIXOSOP5801910121S)',

            'Connection': 'Keep-Alive',

            }
    progress='requests'
    x=requests.get(url,headers=headers).json()
    
    for items in x['GOMOV']:
        
              
                if '~' in items['channel_url']:
                    links=items['channel_url'].split('~')
                    count=0
                    for link in links:
                        progress='Check'+str(count)
                        count+=1
                        name1,match_s,res,check=server_data('https://drive.google.com/file/d/%s/view'%link,original_title)
                        all_links.append((name1,'https://drive.google.com/file/d/%s/view'%link,'Google',res))
                        global_var=all_links
                if 'download' in items:
                    name1,match_s,res,check=server_data(items['download'],original_title)
                    all_links.append((name1,items['download'],match_s,res))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            