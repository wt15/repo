# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()

    all_links=[]
    html=requests.get('https://hindmovie.com/?s='+clean_name(original_title,1).replace(' ','+'),headers=base_header).content
    print 'https://hindmovie.com/?s='+clean_name(original_title,1).replace(' ','+')
    regex='<a class="entry-title-link" rel="bookmark" href="(.+?)">(.+?)<'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
    count=0
    for link,title in match:
        progress='Links-'+str(count)
        count+=1
        z=requests.get(link,headers=base_header).content
        print link
        
        regex='http://nulleddb.com/(.+?)"'
        m=re.compile(regex).findall(z)
        
        for links in m:
            print links
            progress='Links2-'+str(count)
            y=requests.get('http://nulleddb.com/'+links,headers=base_header).content
            if 'name="_csrfToken"' not in y:
                continue
            regex='name="_csrfToken" autocomplete="off" value="(.+?)"'
            cst=re.compile(regex).findall(y)[0]
            regex='name="ad_form_data" value="(.+?)"'
            ads=re.compile(regex).findall(y)[0]
            regex='name="_Token\[fields\]" autocomplete="off" value="(.+?)"'
            tk1=re.compile(regex).findall(y)[0]
            regex='name="_Token\[unlocked\]" autocomplete="off" value="(.+?)"'
            tk2=re.compile(regex).findall(y)[0]
   
            if clean_name(original_title,1).lower() in title.lower() and show_original_year in title:
                

                headers = {
                   
                    
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                    'Referer': 'https://hindlink.xyz/'+links,
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
    
                }
                cookies = {
                  
                    'csrfToken': cst,
                    
                }
                data = {
                  '_method': 'POST',
                  '_csrfToken': cst,
                  'ad_form_data': ads,
                  '_Token[fields]': tk1,
                  '_Token[unlocked]': tk2
                }
                time.sleep(2)
                progress='requests-'+str(count)
                response = requests.post('https://nulleddb.com/links/go', headers=headers,cookies=cookies, data=data).json()
         
             
                progress='Check-'+str(count)
                name1,match_s,res,check=server_data(response['url'],original_title)
                        
            
                if check :
                    all_links.append((name1,response['url'],match_s,res))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var