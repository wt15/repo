# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
try:
 import xbmcgui
 local=False
except:
 local=True
 
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header,res_q
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[111]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]



    if tv_movie=='movie':
      
      imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
      
      x=requests.get(imdbid_data).json()
      imdbid=x['imdb_id']

    else:
       imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
      
       x=requests.get(imdbid_data).json()
       imdbid=x['external_ids']['imdb_id']
    if tv_movie=='tv':
        search_s=imdbid+'+'+'s%se%s'%(season_n,episode_n)
    else:
        search_s=imdbid
    x=requests.get('https://rarbgtor.org/torrents.php?search=%s&order=seeders&by=DESC'%search_s,headers=base_header).content
   
    regex='<tr class="lista2">(.+?)</td></tr>'
    match_pre=re.compile(regex,re.DOTALL).findall(x)
    mag_result={}
    print x
    for item in match_pre:
        
        regex='onmouseout="return nd\(\);" href="(.+?)" title="(.+?)".+?<td align="center"  width=".+?" class="lista">(.+?)<.+?<font color=".+?">(.+?)<.+?class="lista">(.+?)<'
        match=re.compile(regex).findall(item)
        
        for link,title,size,seed,peer in match:
            
         
            y=requests.get('https://rarbgtor.org'+link,headers=base_header).content
            regex='"magnet:(.+?)"'
            m=re.compile(regex).findall(y)[0]
        
            res=res_q(title)
            all_links.append((title,'magnet:'+m,'- RARG - '+str(size)+' GB'+' {P-%s/S-%s}'%(peer,seed),res))
            
            global_var=all_links
    return global_var
           