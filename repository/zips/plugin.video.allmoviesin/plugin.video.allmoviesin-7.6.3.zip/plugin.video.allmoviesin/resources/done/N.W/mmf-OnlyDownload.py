# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[41]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    import cfscrape
    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    
  
    if tv_movie=='movie':
        q=(original_title.replace('%20','+')+' '+show_original_year)
    else:
        q=(original_title.replace('%20',' ').replace('%27','')+' s'+season_n+' e'+episode_n)
    token=cfscrape.get_tokens('https://moviefiles.org',user_agent='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0')

    x=requests.get(domain_s+'moviefiles.org/?search='+q,headers=headers,cookies=token[0]).content

    regex='<a href="file.php.+?d=(.+?)">(.+?)<'
    match=re.compile(regex).findall(x)

    for links,name1 in match:
        if stop_all==1:
             break
        headers = [
        ('Host', 'moviefiles.org'),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv,60.0) Gecko/20100101 Firefox/60.0'),
        ('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Accept-Language', 'en-US,en;q=0.5'),
        ('Connection', 'keep-alive'),
        ('Upgrade-Insecure-Requests', '1'),
        ('Pragma', 'no-cache'),
        ('Cache-Control', 'no-cache'),
        ]
        from cookielib import CookieJar

        cj = CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        # input-type values from the html form
        opener.addheaders =(headers)
        response = opener.open(domain_s+'moviefiles.org/file.php?id='+links)
        
        
           
           
        headers = {
                'Host': 'moviefiles.org',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
        }
          

        html = requests.get(domain_s+'moviefiles.org/file.php?id='+links+'&dl', headers=headers,cookies=cj).content

        regex="<p><a href='(.+?)'"
        f_link=re.compile(regex).findall(html)[0]
        regex="<strong>Size: </strong>(.+?)<"
        size=re.compile(regex).findall(html)[0]
        
        
              
        f_link=f_link.replace('\n','').replace('\t','').replace('\r','').strip()
        if "1080" in name1:
              res="1080"
        elif "720" in name1:
              res="720"
        elif "480" in name1:
              res="720"
        elif "hd" in name1.lower():
              res="HD"
        else:
             res=' '
          
        all_links.append((name1,f_link,'Google'+' - '+size,res))
        global_var=all_links
    return global_var
    