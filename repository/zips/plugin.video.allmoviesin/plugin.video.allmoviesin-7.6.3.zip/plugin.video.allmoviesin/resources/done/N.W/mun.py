# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[3]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    
    search_title=clean_name(original_title,1).replace(' ','+')
    url='https://mundopelis.xyz/index.php?option=com_spmoviedb&view=searchresults&searchword=%s&type=movies&Itemid=544'%search_title
    x=requests.get(url,headers=base_header).content
    regex='<div class="movie-poster">.+?href="(.+?)".+?<h4 class="movie-title">(.+?)<'
    m=re.compile(regex,re.DOTALL).findall(x)
    for link,title in m:
   
        if '(' in title:
            title=title.split('(')[0].strip()
        if title.lower()!=clean_name(original_title,1).lower():
            continue
    
        y=x=requests.get('https://mundopelis.xyz'+link,headers=base_header).content
        regex='iframe.+?src="(.+?)"'
        m2=re.compile(regex,re.IGNORECASE).findall(y)
        lk=[]
        for links in m2:
            name2,match_s,res,check=server_data(links,original_title)
               
            if check:
                if res==' ':
                    res='720'
                res=res.replace('p','')
                all_links.append((name2,links,match_s,res))
                
                global_var=all_links
    return all_links
