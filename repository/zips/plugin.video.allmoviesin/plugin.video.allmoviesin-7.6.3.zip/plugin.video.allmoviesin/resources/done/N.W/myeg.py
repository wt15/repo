# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[1]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    search_url=clean_name(original_title,1)
    progress='Start'
    start_time=time.time()
    all_links=[]
    progress='requests'
    html=requests.get('https://myegy.cc/latest?search='+clean_name(original_title,1).replace(" ","+"),headers=base_header).content
    regex='<a class="item  (.+?)" href="(.+?)".+?<span class="title">(.+?)</span>'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html)
    count=0
    for type,link,name in match:
        progress='Links-'+str(count)
        count+=1
        if type==tv_movie.replace('movie','movies') and name.lower()==search_url.lower():
            progress='requests-'+str(count)
            y=requests.get('https://myegy.cc/'+link,headers=base_header).content
            regex='<div class="size">.+?</div>(.+?)</div>.+?<div class="wlinks">(.+?)</div>'
            progress='Regex-'+str(count)
            m=re.compile(regex,re.DOTALL).findall(y)
            for res_pre,data in m:
                if '240' in res_pre or '360' in res_pre:
                    continue
                regex='a href="(.+?)"'
                progress='Regex2-'+str(count)
                m1=re.compile(regex,re.DOTALL).findall(data)
                for links in m1:
                    progress='requests2-'+str(count)
                    z=requests.get('https://myegy.cc/'+links,headers=base_header).content
                    regex='iframe .+?src="(.+?)"'
                    progress='Regex3-'+str(count)
                    m2=re.compile(regex,re.DOTALL).findall(z)[0]
                    progress='Check-'+str(count)
                    name1,match_s,res,check=server_data(m2,original_title)
                            
                              
                    if check :
                        all_links.append((name1.replace('MyEgy.Tv.',''),m2,match_s,res_pre.replace('p','').replace('\n','').replace('\t','').replace(' SQ','')))
                        global_var=all_links
                        
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            
                    
    