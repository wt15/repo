# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

rating=['External','uptobox']

color=all_colors[54]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    if tv_movie=='tv':
       b_url='easyaccesscinema.top'
    else:
       b_url='easyaccesscinema.net'
    all_links=[]
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Referer': 'http://%s/'%b_url,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    data = {
      'titleonly': '3',
      'do': 'search',
      'subaction': 'search',
      'story': clean_name(original_title,1),
      'x': '0',
      'y': '0'
    }
    progress='requests'
    response = requests.post('http://%s/'%b_url, headers=headers, data=data).content
    regex='<span class="tcarusel-item-year">(.+?)<.+?<div class="tcarusel-item-title".+?<a href="(.+?)">(.+?)</a>'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(response)
    count=0
   
    for year,link,name in match:
        progress='Links-'+str(count)
        count+=1
        check=False
        if tv_movie=='tv':
            if '-%s-'%season in link:
                check=True
        else:
            if show_original_year in  year:
               check=True
       
        
        if check:
            progress='requests2'
            
            y=requests.get(link, headers=headers).content
            if tv_movie=='tv':
                regex='<option value="(.+?)">Episode %s</option>'%episode
            else:
                regex='iframe .+? src="(.+?)"'
            m2=re.compile(regex).findall(y)
            print m2
            for link in m2:
                progress='Check-'+str(count)
                name1,match_s,res,check=server_data(link,original_title)
                    
                if check:
                      all_links.append((name1.replace("%20"," "),link,match_s,res))
                
                      global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    
