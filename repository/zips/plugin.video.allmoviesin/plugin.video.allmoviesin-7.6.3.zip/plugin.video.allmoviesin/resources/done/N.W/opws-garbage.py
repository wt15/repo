# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[50]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    import cfscrape,urlparse
 
    if tv_movie=='movie':
      url='http://openloadmovies.biz/?s='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    else:
      url='http://openloadmovies.biz/?s='+clean_name(original_title,1).replace(' ','+')
    html,token=cloudflare_request(' http://openloadmovies.biz/?s=tomb+raider+2018')
   
    all_links=[]

    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    print url
    html=requests.get(url,cookies=token[0],headers=token[1]).content

    regex_pre='<article>(.+?)</article>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)

    
    for items in match_pre:
       print items
       if stop_all==1:
                    break
       regex='<div class="title".+?a href="(.+?)">(.+?)</a>'
       match=re.compile(regex,re.DOTALL).findall(items)
       for link,name_in in match:
         if stop_all==1:
                    break
         if clean_name(original_title,1).lower() in name_in.lower():
          
           if tv_movie=='tv':
              y1=requests.get(link,cookies=token[0],headers=token[1]).content
            
              regex_pre='<li>(.+?)</li>'
              match_pre=re.compile(regex_pre,re.DOTALL).findall(y1)
              for data in match_pre:
                print data
                if stop_all==1:
                    break
                if 'numerando' in data:
                  regex='<div class="numerando">%s - %s</div>.+?<div class="episodiotitle">.+?<a href="(.+?)"'%(season,episode)
                 
                  match2=re.compile(regex,re.DOTALL).findall(data)
                  if len(match2)>0:
                      y=requests.get(match2[0],cookies=token[0],headers=token[1]).content
                      
                      regex='LoadPlayer\("(.+?)","(.+?)"'
                      match_l=re.compile(regex).findall(y)
                      data = [
                          ('id', match_l[0][0]),
                          ('data', match_l[0][1]),
                       ]
                  
                      response = requests.post('https://openloadmovies.biz/wp-content/plugins/apiplayer/load.php', headers=token[1], cookies=token[0], data=data).content
                   
                      regex='{(.+?)}'
                      match_l=re.compile(regex).findall(response)
                      
                      
                      for data in match_l:
                          if stop_all==1:
                                break
                          if 'file' in data:
                           
                           in_d=json.loads('{'+data+'}')
                          
                           all_links.append((original_title.replace("%20"," "),in_d['file'],'Direct',in_d['label']))
                           global_var=all_links
                      regex='<iframe src="(.+?)"'
                      match=re.compile(regex).findall(response)
                      for links in match:
                        
                        if stop_all==1:
                            break
                        parsed = urlparse.urlparse(links)
                        id= urlparse.parse_qs(parsed.query)['id']
                 
                        x=requests.get('https://vinh.vproxy.online/api/v1/caches/get?id='+id[0],headers=token[1]).json()
                  
                        for li in x['videos']:
                            if stop_all==1:
                                break
                            all_links.append((original_title.replace("%20"," "),li['file'],'Direct',li['label']))
                            global_var=all_links
                      break
                      
           else:
             
               y=requests.get(link,cookies=token[0],headers=token[1]).content
               regex='LoadPlayer\("(.+?)","(.+?)"'
               match_l=re.compile(regex).findall(y)
               data = [
                  ('id', match_l[0][0]),
                  ('data', match_l[0][1]),
               ]

               response = requests.post('https://openloadmovies.biz/wp-content/plugins/apiplayer/load.php', headers=token[1], cookies=token[0], data=data).content


             
               regex='{(.+?)}'
               match_l=re.compile(regex).findall(response)
         
               for data in match_l:
                  if 'file' in data:
                   
                   in_d=json.loads('{'+data+'}')
                  
                   all_links.append((original_title.replace("%20"," "),in_d['file'],'Direct',in_d['label']))
                   global_var=all_links
               regex='<iframe src="(.+?)"'
               match=re.compile(regex).findall(response)
               for links in match:
                 
                    parsed = urlparse.urlparse(links)
                    id= urlparse.parse_qs(parsed.query)['id']
             
                    x=requests.get('https://vinh.vproxy.online/api/v1/caches/get?id='+id[0],headers=head).json()
              
                    for li in x['videos']:
                        all_links.append((original_title.replace("%20"," "),li['file'],'Direct',li['label']))
                        global_var=all_links
    return global_var
    