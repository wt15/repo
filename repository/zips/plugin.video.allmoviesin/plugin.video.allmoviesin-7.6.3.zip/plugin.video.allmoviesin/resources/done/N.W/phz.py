# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,client,parseDOM
type=['movie','tv','rd']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[93]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    base_link = 'http://phazeddl.me'
    search_link = '/?s=%s'
    title =clean_name(original_title,1)
    
    if tv_movie=='tv':
        query = '%s S%sE%s' % (title, season_n, episode_n) 
    else:
        query ='%s %s' % (title, show_original_year)
    if tv_movie=='tv':
       hdlr = 'S%sE%s' % (season_n, episode_n)
    else:
       hdlr = show_original_year
    
    url = search_link % urllib.quote_plus(query)
    url = urlparse.urljoin(base_link, url)

    r = client.request(url)

    posts = parseDOM(r, 'article', attrs={'class': 'item-list'})
   

    items = []
 

    for post in posts:
        
        t = parseDOM(post, 'h2', attrs={'class': 'post-box-title'})[0]
        
        regex='href="(.+?)">(.+?)<'
        match=re.compile(regex).findall(t)
        for link,title in match:
          
          if clean_name(original_title,1).lower() in title.lower():
            x=client.request(link)
            regex_pre='<span id="more-(.+?)<div class="share-post"> '
            match_pre=re.compile(regex_pre).findall(x)
            regex='<a href="(.+?)" class="external" rel="nofollow" target="_blank">'
            match_in=re.compile(regex).findall(match_pre[0])
            
              
            for url in match_in:
               
                host = url.split('//')[1].replace('www.','')
                host = host.split('/')[0].lower()

               
                
                if host in rd_domains and '.rar' not in url and '.iso' not in url and '.zip' not in url:
                    name1,match_s,res,check=server_data(url,original_title)
                    
                    
                    if check :
                        if '.rar' not in name1:
                            all_links.append((name1,url,match_s,res))
                            global_var=all_links
                            
    return global_var
          
            
            
            


        
     