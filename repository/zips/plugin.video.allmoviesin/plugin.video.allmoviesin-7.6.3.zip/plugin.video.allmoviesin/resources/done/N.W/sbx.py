import requests,re
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,client
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[78]

def __decrypt( ciphertext):
        import pyaes
        key = b'\x38\x36\x63\x66\x37\x66\x66\x63\x62\x33\x34\x64\x37\x64\x33\x30\x64\x33\x62\x63\x31\x35\x61\x38\x35\x31\x36\x33\x34\x33\x32\x38'
        ciphertext = base64.b64decode(ciphertext)
        
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationECB(key))
        plaintext = decrypter.feed(ciphertext)
        plaintext += decrypter.feed()

        return plaintext
def __get_episode_url( data,season, episode):
            base_link = 'http://sbrapi.cc'
            show_search = '/api/serials/tv_list/?query=%s'
            episode_details = '/api/serials/episode_details_s/?h=%s&u=%s&y=%s'
            fetcher = '/api/serials/mw_sign/?token=%s'
            headers = {
                'User-Agent': 'Show Box'
            }
            query =clean_name (data,1).lower().replace(' ', '+')
            path = show_search % query
            url = urlparse.urljoin(base_link, path)

            response = requests.get(url, headers=headers).content
            
            show_id = json.loads(response)[0]['id']

            path = episode_details % (show_id,season, episode)
            url = urlparse.urljoin(base_link, path)

            response = requests.get(url, headers=headers).content
           
            token_encrypted = json.loads(response)[0]['sources'][0]['hash']


            token = __decrypt(token_encrypted)
            
            path = fetcher % token
            url = urlparse.urljoin(base_link, path)
            print url
            return url
def __get_movie_url( data):
            headers = {
                'User-Agent': 'Show Box'
            }
           
            movie_search = '/api/serials/movies_list/?query=%s'
            movie_details = '/api/serials/movie_details/?id=%s'
            fetcher = '/api/serials/mw_sign/?token=%s'
            base_link = 'http://sbrapi.cc'
            query = clean_name(data,1).lower().replace(' ', '+')
            path = movie_search % query
            url = urlparse.urljoin(base_link, path)
            print url
            response = requests.get(url, headers=headers).content

            movie_id = json.loads(response)[0]['id']

            path = movie_details % movie_id
            url = urlparse.urljoin(base_link, path)

            response = requests.get(url, headers=headers).content
            
            token_encrypted = json.loads(response)['langs'][0]['sources'][0]['hash']

            token = __decrypt(token_encrypted)

            path = fetcher % token
            url = urlparse.urljoin(base_link, path)

            return url

        


def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    priority = 1
    language = ['en']
    domains = ['movietimeapp.com']

    headers = {
        'User-Agent': 'Show Box'
    }
    if tv_movie=='movie':
      url=__get_movie_url(original_title)
    else:
      url=__get_episode_url(original_title,season_o,episode_o)
    link = urlparse.parse_qs(urlparse.urlparse(url).query)['token'][0]
    name1,match_s,res,check=server_data(link,original_title)
         
    if check :
        all_links.append((name1,link,match_s,res))
        global_var=all_links
    return global_var