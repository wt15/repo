import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[83]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    if tv_movie=='movie':
      url='http://shacktv.com:8080/enigma2.php?username=123&password=123&type=get_vod_streams&cat_id=0'

    else:
      url='http://shacktv.com:8080/enigma2.php?username=123&password=123&type=get_series&cat_id=104'
    html=requests.get(url,headers=headers).content
    print html
    regex_pre='<channel>(.+?)</channel>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    for items in match_pre:
       if tv_movie=='movie':
         regex='<title>(.+?)</title>.+?<stream_url>(.+?)</stream_url>'
       else:
         regex='<title>(.+?)</title>.+?<playlist_url>(.+?)</playlist_url>'
       match=re.compile(regex,re.DOTALL).findall(items)
       for name,link in match:
         
         if clean_name(original_title,1).lower().strip()== name.decode('base64').lower().strip():
            
            f_link=link.replace('<![CDATA[','').replace(']]>','')
            if tv_movie=='tv':
               x=requests.get(f_link,headers=headers).content
               regex='<title>(.+?)</title>.+?<playlist_url>(.+?)</playlist_url>'
               match_in=re.compile(regex,re.DOTALL).findall(x)
               for se,link_s in match_in:
                  if ('Season '+season)==se.decode('base64'):
                    y=requests.get(link_s.replace('<![CDATA[','').replace(']]>',''),headers=headers).content
                    regex='<title>(.+?)</title>.+?<stream_url>(.+?)</stream_url>'
                    match_e=re.compile(regex,re.DOTALL).findall(y)
                    f_link=''
                    for ep,link_e in match_e:
                      
                      if ('Episode '+episode_n)==ep.decode('base64'):
                        f_link=link_e.replace('<![CDATA[','').replace(']]>','')
            link=requests.get(f_link, stream=True)
            if '1080' in link.url:
                rez = '1080p'
            
                
            else: rez = '720p'

            name1s=link.url.split('/')
            nam1=name1s[len(name1s)-1].replace('.mp4','')
            all_links.append((nam1,link.url,'Direct',rez))
           
            global_var=all_links
    return global_var