
import requests,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header

type=['tv','movie']
import urllib2,urllib,logging,base64,json
color=all_colors[13]


def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
        search_str=clean_name(original_title,1)+' '+season
    else:
        search_str=clean_name(original_title,1)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Accept-Encoding':'UTF-8',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('suggest', 'true'),
        ('query', search_str),
    )

    response = requests.get('https://vipmovies.to/api/search', headers=headers, params=params).json()
    
    


    for items in response['data']['contents']:
        check=False
       
       
        
        if tv_movie=='movie':
            if items['name'].lower()==clean_name(original_title,1).lower() and  show_original_year in items ['released']:
                
                check=True
        else:
            if items['name'].lower()==clean_name(original_title,1).lower()+' '+season:
                check=True
    
        if  check==True:
            lk_pre='https://vipmovies.to/watch/'+items['hash']+'/'+items['slug']
            x=requests.get('https://vipmovies.to/api/episodes/list/'+items['hash'],headers=base_header).json()
           
            if 1:#tv_movie=='tv':
                for ep in x['data']:
                    ch=False
                    if tv_movie=='tv':
                        if ep['name']==episode_n:
                            ch=True
                    else:
                        ch=True
                    if ch:
                        lk_x=requests.get('https://vipmovies.to/api/episode/'+ep['hash'],headers=base_header).json()
                        f_lk=lk_x['data']['source']
                        f_lk_s=f_lk
                        print f_lk_s
                        if 'watch.lavacdn' in f_lk:
                            headers = {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Referer': lk_pre,
                                'Upgrade-Insecure-Requests': '1',
                                'Pragma': 'no-cache',
                                'Cache-Control': 'no-cache',
                            }

                          
                            response = requests.get(f_lk, headers=headers).content
                            
                            regex="file: '(.+?)'"
                            f_lk=re.compile(regex).findall(response)
                            if len(f_lk)>0:
                                y=requests.get(f_lk[0],headers=base_header).content
                                res=' '
                                if 'RESOLUTION=' in y:
                                    regex='RESOLUTION=(.+?)\n'
                                    res=re.compile(regex).findall(y)[0]
                                    res=res.split('x')[1]
                                if 'google' in f_lk[0]:
                                    srv='Google'
                                    
                                else:
                                    srv='Direct'
                                f_lk_n=f_lk[0].split('/')
                                f_lk_n.pop(len(f_lk_n)-1)
                                
                                f_lk_n=''.join(f_lk_n)
                           
                                headers = {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                                    'Accept': '*/*',
                                    
                                    'Accept-Encoding':'gzip, deflate, br',
                                    'Accept-Language': 'en-US,en;q=0.5',
                                    'Connection': 'keep-alive',
                                    'Referer': f_lk_s,
                                    'Pragma': 'no-cache',
                                    'Cache-Control': 'no-cache',
                                    'TE': 'Trailers',
                                }
                                head=urllib.urlencode(headers)
                                url=f_lk[0]+"|"+head
                                all_links.append((original_title.replace("%20"," "),url,'Direct',res))                
                        
                                global_var=all_links
                            regex='sources.+?\[(.+?)\]'
                            match=re.compile(regex,re.DOTALL).findall(response)
                            if len(match)>0:
                                
                                j_m=json.loads('['+match[0]+']')
                                
                                for it_lk in j_m:
                                    res=it_lk['label']
                                    lk=it_lk['file']
                                    res=res.replace('HD','720')
                                    all_links.append((original_title,lk,'Direct',res))
                                    global_var=all_links
                        else:
                            name1,match_s,res,check=server_data(f_lk,original_title)
                
                            if check:
                                all_links.append((name1.replace("%20"," "),f_lk,match_s,res))                
                                        
                                global_var=all_links
                                
            
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    