# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[19]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        
        

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0',
            'TE': 'Trailers',
        }
        all_links=[]
        base_link = domain_s+'openloadmovie.org'
        search_id=clean_name(original_title,1)
       
        movie_link = '%s/movies/%s-%s/' %(base_link,search_id.replace(' ','-'),show_original_year)

        html,cook = cloudflare_request(movie_link,headers=headers)
        links = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(html)
        count = 0
        logging.warning( movie_link)
        
        
        headers = {
            'authority': 'openloadmovies.ch',
            'accept': '*/*',
            'sec-fetch-dest': 'empty',
            'x-requested-with': 'XMLHttpRequest',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://openloadmovies.ch',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'referer': movie_link,
            'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
            
        }
        regex="class='dooplay_player_option' data-type='(.+?)' data-post='(.+?)' data-nume='(.+?)'"
        m=re.compile(regex).findall(html)
        for dt,dp,dn in m:
            data = {
              'action': 'doo_player_ajax',
              'post': dp,
              'nume': dn,
              'type': dt
            }

            response = requests.post('https://openloadmovies.ch/wp-admin/admin-ajax.php', headers=headers, data=data).content
            regex="src='(.+?)'"
            link=re.compile(regex).findall(response)[0]
            name1,match_s,res,check=server_data(link,original_title)
            
            if check:
               all_links.append((name1,link,match_s,res))
               global_var=all_links
        return global_var