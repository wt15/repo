import requests
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,parseDOM,cloudflare_request
type=['movie','tv']

import urllib2,urllib,logging,base64,json,urlparse
color=all_colors[83]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    



 

    global global_var,stop_all

    all_links=[]
    base_link='http://www8.fmovies.ag'
    clean_title=clean_name(original_title,1)
    if tv_movie=='movie':
      query = ('/search/%s.html' % clean_name(original_title,1))
    else:
      query = ('/search/%s.html' % (clean_name(original_title,1)+' '+season))
    url = urlparse.urljoin(base_link, query).replace(' ','+')
    
    headers={
    'User-Agent':"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    }
    search_response,cook = cloudflare_request(url)

    search_response=requests.get(url,headers=cook[1],cookies=cook[0]).content

    regex='<div class="ml-item">(.+?)</div>'
    match_pre=re.compile(regex,re.DOTALL).findall(search_response)
    
    for items in match_pre:
        if stop_all==1:
            break
        regex='<a href="(.+?)".+?<h2>(.+?)<'
        match=re.compile(regex,re.DOTALL).findall(items)
        for link,name in match:
            if stop_all==1:
                break
            check=False
            if tv_movie=='tv':
              if 'S'+season_n in name:
                check=True
            else:
               check=True
            if clean_name(original_title,1).lower() in name.lower() and check:
                f_link=link
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': f_link,
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    x=requests.get(f_link,headers=cook[1],cookies=cook[0]).content
    regex="ip_build_player\((.+?),'(.+?)','(.+?)',(.+?)\)"
    m=re.compile(regex).findall(x)
    regex='data-server="(.+?)"'
    servers_pre=re.compile(regex).findall(x)
    servers=[]
    for items in servers_pre:
       if stop_all==1:
             break
       if items not in servers:
            servers.append(items)
    
    for items in servers:
        if stop_all==1:
            break
        if tv_movie=='tv':
          ipname=episode
          refer='%s?p=%s&s=%s'%(f_link,episode,season)
        else:
          ipname='1'
          refer=f_link
        data = {
          'ip_film': m[0][0],
          
          
          'ip_server': items,
          'ip_name': ipname,
          'ipplugins': m[0][3],
          
        }
        
        
        response = requests.post('http://www3.fmovies.ag/ip.file/swf/plugins/ipplugins.php', headers=cook[1], data=data,cookies=cook[0]).json()
        
        print response
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer':refer ,
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        for n in range (0,10):
            if stop_all==1:
                    break
            params = (
                ('u', response['s']),
                ('w', '100%'),
                ('h', '500'),
                ('s', '4'),
                ('n', n),
            )

            response2 = requests.get('http://www3.fmovies.ag/ip.file/swf/ipplayer/ipplayer.php', headers=cook[1], params=params,cookies=cook[0]).json()
            link=response2['data']
            if 'http' not in link:
              link='http:'+link
            if link=='http:':
              break
            name2,match_s,res,check=server_data(link,original_title)
            
            if check:
                link=link.replace('id=','i=playing&id=')
                print link
                
                if 'streamloverx' in link:
                    
                    cookies = {
                         'popcashpu': '1',
                    }

                   

                    headers = {
                        'Pragma': 'no-cache',
                        'Accept-Encoding': 'gzip, deflate',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
                        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                        'Referer': link,
                        'Connection': 'keep-alive',
                        'Cache-Control': 'no-cache',
                    }
                    
                    response_e = requests.get(link, headers=headers, params=params, cookies=cookies).content
                    
                    regex='hls/movie.m3u8","(.+?)"'
                    link=re.compile(regex).findall(response_e)[0]
                all_links.append((clean_name(original_title,1),link,match_s,'720'))
                        
                global_var=all_links
    return global_var
