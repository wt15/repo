# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,cleantitle,client,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[22]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        all_links=[]
        url='http://www2.flenix.org/search/%s.html'%clean_name(original_title,1)
        html=client.request(url)
        regex_pre='<div class="ml-item">(.+?)</button>'
        match=re.compile(regex_pre,re.DOTALL).findall(html)
        
        
        for items in match:
          regex='a href="(.+?)".+?title="(.+?)"'
          match2=re.compile(regex).findall(items)
          regex_y='<div class="jt-info">(.+?)<'
          match_y=re.compile(regex_y).findall(items)
         
          for link,name_in in match2:
            
             check=False
             if tv_movie=='tv':
               if clean_name(original_title,1).lower() in name_in.lower() and '- s'+season_n in name_in.lower():
                 check=True
             else:
                 if len (match_y)>0:
                   if clean_name(original_title,1).lower()==name_in.lower() and show_original_year in match_y[0]:
                     check=True
                 else:
                    if clean_name(original_title,1).lower()==name_in.lower():
                     check=True
             
             if check:
                
                x=client.request(link)
                print link
                if tv_movie=='tv':
                  
                  regex_pre='<a class="episode_%s btn-eps first-ep"(.+?)</a>'%episode
                  match_pre=re.compile(regex_pre).findall(x)
                  regex='href="(.+?)"'
                  match_in=re.compile(regex).findall(match_pre[0])
                  
                  x=client.request(match_in[0])
                  
                 
                  
                  
                
                
                regex='<li><a class="(.+?)" data-film="(.+?)" data-name="(.+?)" data-server="(.+?)"'
                match_in=re.compile(regex).findall(x)
                
                for cls,ip_film,ip_name,ip_server in match_in:
                
                    headers = {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Cache-Control': 'no-cache',
                            'Connection': 'keep-alive',
                           
                            'Pragma': 'no-cache',
                            'Referer':link,
                            'Upgrade-Insecure-Requests': '1',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                        }
                    post = {'ipplugins': 1,'ip_film': ip_film, 'ip_server': ip_server, 'ip_name': ip_name,'fix': "0"}
                    
                    p1=requests.post('http://flenix.org/ip.file/swf/plugins/ipplugins.php', data=post,headers=headers).json()
                    
                    p2 = requests.get('http://flenix.org/ip.file/swf/ipplayer/ipplayer.php?u=%s&s=%s&n=0' %(p1['s'],ip_server),headers=headers).json()
                    counter=0
                    
                    while 1:
                    
                    
                        if counter>5:
                          break
                        counter+=1
                        if 'http' not in p2["data"]:
                          url =  "https:%s" %p2["data"].replace("\/","/")
                        else:
                          url =  p2["data"].replace("\/","/")
                        name1,match_s,res,check=server_data(url,original_title)
                        if clean_name(original_title,1).replace('.','').replace(' ','').replace("'",'').replace("-",'') not in name1.replace('.','').replace(' ','').replace("'",'').replace("-",''):
                          name1=clean_name(original_title,1)
                        if check:
                              all_links.append((name1.replace("%20"," "),url,match_s,'720'))
                              global_var=all_links
                        if p2['next']==0:
                          break
                        p2 = requests.get('http://flenix.org/ip.file/swf/ipplayer/ipplayer.php?u=%s&s=%s&n=%s' %(p1['s'],ip_server,p2['next']),headers=headers).json()
        return global_var
            