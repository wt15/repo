# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[106]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]

    all_links=[]
    base_link = 'https://movies7k.online'
    search = '/search_movies?s='
    search_id=clean_name(original_title,1)
    
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))
    headers = base_header

    OPEN,cookie = cloudflare_request(start_url)

    Regex = re.compile('class="movie-list text-center".+?title="(.+?)".+?href="(.+?)"',re.DOTALL).findall(OPEN)
   
    for name,item_url in Regex:
        if stop_all==1:
            break
        if 'Hindi' not in name:

            item_url=base_link+item_url
            release=''
            if '(' in name:

                release=name.split('(')[-1].split(')')[0]

                name=name.split('(')[0]

           
           
            if not show_original_year == release:

                continue

            if search_id.lower() in name.lower().strip():
                OPEN,cookie = cloudflare_request(item_url)

                quality_r = re.compile('class="mpaa">(.+?)</span>',re.DOTALL).findall(OPEN)
                o_res=' '
                for quality in quality_r:

                    if "1080" in quality:
                      o_res="1080"
                    elif "720" in quality:
                      o_res="720"
                    elif "480" in quality:
                       o_res="480"
                    else:
                       o_res=' '



                

               

                Regex = re.compile('width="485".+?href="(.+?)"',re.DOTALL).findall(OPEN)

                for link in Regex:

                    if '/watching/' not in link:

                        if 'http' not in link:

                            link = 'http:'+link

                       
                        name2,match_s,res,check=server_data(link,original_title)
                        if res==' ':
                          res=o_res
                        
                        if check:

                            all_links.append((name2,link,match_s,res))
                            
                            global_var=all_links
    return all_links