import requests,re
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s

type=['movie']
import urllib2,urllib,logging
color=all_colors[42]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    all_links=[]

    url=domain_s+'en.movdb.net/search?q='+(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)

    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
 
    html=requests.get(url,headers=headers,verify=False).content
    
    #regex='"BPG=(.+?);'
    #match=re.compile(regex).findall(html)
    cookies={}
    #cookies={'BPG':match[0]}
    html=requests.get(url,headers=headers,cookies=cookies,verify=False).content
    regex_pre='<div class="item">.+?<a href="(.+?)"'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    
    for link in match_pre:
             if stop_all==1:
                break
             y=requests.get(link,headers=headers,cookies=cookies,verify=False).content
             
             regex_p='<div class="play mobiPlay"><a href="(.+?)"'
             match_p=re.compile(regex_p,re.DOTALL).findall(y)
             z=requests.get(match_p[0],headers=headers,cookies=cookies,verify=False).content
             regex='isSupported.+?"(.+?)" \: "(.+?)"'
             match_p2=re.compile(regex,re.DOTALL).findall(z)
             ids=match_p2[0][0].split('/')
             id=ids[len(ids)-2]
            
             name1=id.split('.mp4')[0].replace('-','.')
             if "1080p" in name1:
                    res="1080"
             elif "720p" in name1:
                    res="720"
             elif "480p" in name1:
                    res="720"
             elif "hd" in name1.lower():
                    res="HD"
             else:
                    res=' '
             
             all_links.append((name1,match_p2[0][0],'Direct',res))
             all_links.append((name1,match_p2[0][1],'Direct',res))
             global_var=all_links
    return all_links
            
         
         
         
      
      