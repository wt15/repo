import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser

site1qr = xbmc.translatePath('special://home/addons/script.watchdogs.pair/site1.png')
site2qr = xbmc.translatePath('special://home/addons/script.watchdogs.pair/site2.png')
site3qr = xbmc.translatePath('special://home/addons/script.watchdogs.pair/site3.png')


def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
		function4,
		function5,
		function6
		 )
        
    call = dialog.select('[B][COLOR=white]WATCHDOGS[/COLOR] [COLOR=gold]PAIRING[/COLOR] [/B]', [
    '[B][COLOR=white]      Open Load[/COLOR][/B] [COLOR=gold]QR Code[/COLOR]', 
    '[B][COLOR=white]      Vid Up Me[/COLOR][/B] [COLOR=gold]QR Code[/COLOR]',
    '[B][COLOR=white]      VShare[/COLOR][/B] [COLOR=gold]QR Code[/COLOR]',
    '[B][COLOR=white]      Open Load[/COLOR][/B] [COLOR=cyan]Website[/COLOR]', 
    '[B][COLOR=white]      Vid Up Me[/COLOR][/B] [COLOR=cyan]Website[/COLOR]',
    '[B][COLOR=white]      VShare[/COLOR][/B] [COLOR=cyan]Website[/COLOR]',
	])
    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def function1():
	xbmc.executebuiltin('ShowPicture('+site1qr+')')

	
def function2():
	xbmc.executebuiltin('ShowPicture('+site2qr+')')
	
def function3():
	xbmc.executebuiltin('ShowPicture('+site3qr+')')
	
    
def function4():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/pair' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/pair')

        
def function5():
    if myplatform == 'android': # Android 
       opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://vidup.me/pair' ) )
    else:
        opensite = webbrowser . open('https://vidup.me/pair')
        
def function6():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://vshare.eu/pair' ) )
    else:
        opensite = webbrowser . open('http://vshare.eu/pair')
		
     
menuoptions()
